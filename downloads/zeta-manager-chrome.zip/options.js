"use strict";
(() => {
  // src/shared/messages.ts
  function sendToBackground(request) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(request, (response) => {
          const err = chrome.runtime.lastError;
          if (err || !response) {
            resolve({
              ok: false,
              error: err?.message ?? "background service worker \u304B\u3089\u5FDC\u7B54\u304C\u3042\u308A\u307E\u305B\u3093",
              code: "INTERNAL"
            });
            return;
          }
          resolve(response);
        });
      } catch (e) {
        resolve({
          ok: false,
          error: e instanceof Error ? e.message : String(e),
          code: "INTERNAL"
        });
      }
    });
  }

  // src/shared/utils.ts
  function isLocalEndpoint(url) {
    try {
      const u = new URL(url);
      return u.hostname === "localhost" || u.hostname === "127.0.0.1" || u.hostname === "[::1]" || u.hostname === "::1";
    } catch {
      return false;
    }
  }
  function originPatternOf(url) {
    try {
      const u = new URL(url);
      if (u.protocol !== "http:" && u.protocol !== "https:") return null;
      return `${u.protocol}//${u.hostname}/*`;
    } catch {
      return null;
    }
  }

  // src/options/options.ts
  var MANIFEST_ORIGINS = /* @__PURE__ */ new Set([
    "https://zeta-ai.io/*",
    "http://localhost/*",
    "http://127.0.0.1/*"
  ]);
  var endpointEl = document.getElementById("endpoint");
  var grantBtn = document.getElementById("btnGrant");
  var statusEl = document.getElementById("status");
  var grantedEl = document.getElementById("granted");
  var currentPattern = null;
  function setStatus(message, kind) {
    statusEl.textContent = message;
    statusEl.className = kind;
  }
  async function refreshGrantedList() {
    const all = await chrome.permissions.getAll();
    const optional = (all.origins ?? []).filter((o) => !MANIFEST_ORIGINS.has(o));
    grantedEl.textContent = "";
    if (optional.length === 0) {
      grantedEl.textContent = "\u8FFD\u52A0\u3067\u8A31\u53EF\u3057\u305F origin \u306F\u3042\u308A\u307E\u305B\u3093\u3002";
      return;
    }
    for (const origin of optional) {
      const row = document.createElement("div");
      row.className = "row";
      const code = document.createElement("code");
      code.textContent = origin;
      const btn = document.createElement("button");
      btn.className = "secondary";
      btn.textContent = "\u53D6\u308A\u6D88\u3059";
      btn.addEventListener("click", async () => {
        await chrome.permissions.remove({ origins: [origin] });
        await refreshGrantedList();
      });
      row.appendChild(code);
      row.appendChild(btn);
      grantedEl.appendChild(row);
    }
  }
  async function init() {
    const res = await sendToBackground({ type: "GET_SETTINGS" });
    if (!res.ok) {
      endpointEl.textContent = `\u8A2D\u5B9A\u3092\u8AAD\u307F\u8FBC\u3081\u307E\u305B\u3093: ${res.error}`;
      grantBtn.disabled = true;
      return;
    }
    const settings = res.data.settings;
    const endpoint = settings.provider === "openai-compatible" ? settings.openaiCompatible.endpoint : settings.genericJson.url;
    if (!endpoint) {
      endpointEl.textContent = "\uFF08Endpoint \u672A\u8A2D\u5B9A\uFF09";
      grantBtn.disabled = true;
      return;
    }
    endpointEl.textContent = endpoint;
    if (isLocalEndpoint(endpoint)) {
      grantBtn.disabled = true;
      setStatus("\u30ED\u30FC\u30AB\u30EB endpoint (LOCAL) \u306F\u8FFD\u52A0\u306E\u8A31\u53EF\u306A\u3057\u3067\u4F7F\u7528\u3067\u304D\u307E\u3059\u3002", "ok");
      return;
    }
    currentPattern = originPatternOf(endpoint);
    if (!currentPattern) {
      grantBtn.disabled = true;
      setStatus("Endpoint URL \u304C\u4E0D\u6B63\u3067\u3059\u3002", "error");
      return;
    }
    const granted = await chrome.permissions.contains({ origins: [currentPattern] });
    if (granted) {
      setStatus("\u3053\u306E origin \u306F\u8A31\u53EF\u6E08\u307F\u3067\u3059\u3002", "ok");
    }
  }
  grantBtn.addEventListener("click", async () => {
    if (!currentPattern) return;
    try {
      const granted = await chrome.permissions.request({
        origins: [currentPattern]
      });
      setStatus(
        granted ? "\u8A31\u53EF\u3057\u307E\u3057\u305F\u3002" : "\u8A31\u53EF\u3055\u308C\u307E\u305B\u3093\u3067\u3057\u305F\u3002",
        granted ? "ok" : "error"
      );
    } catch (e) {
      setStatus(e instanceof Error ? e.message : String(e), "error");
    }
    await refreshGrantedList();
  });
  void init();
  void refreshGrantedList();
})();
