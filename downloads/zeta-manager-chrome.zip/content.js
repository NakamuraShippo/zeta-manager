"use strict";
(() => {
  // src/content/conversation-capture.ts
  function partitionVariantSlots(items, anchorCenterX) {
    const groups = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const current = groups[groups.length - 1];
      if (current) {
        const rep = items[current[0]];
        const overlap = Math.min(rep.top + rep.height, item.top + item.height) - Math.max(rep.top, item.top);
        const minHeight = Math.max(1, Math.min(rep.height, item.height));
        if (overlap > minHeight * 0.5) {
          current.push(i);
          continue;
        }
      }
      groups.push([i]);
    }
    const visible = [];
    const displaced = [];
    for (const group of groups) {
      if (group.length === 1) {
        visible.push(group[0]);
        continue;
      }
      let best = group[0];
      for (const idx of group) {
        if (Math.abs(items[idx].centerX - anchorCenterX) < Math.abs(items[best].centerX - anchorCenterX)) {
          best = idx;
        }
      }
      visible.push(best);
      for (const idx of group) {
        if (idx !== best) displaced.push(idx);
      }
    }
    return { visible, displaced };
  }
  var ConversationStore = class {
    byKey = /* @__PURE__ */ new Map();
    /** active なメッセージの時系列順 messageKey リスト（唯一の順序ソース） */
    order = [];
    pos = /* @__PURE__ */ new Map();
    dirtyKeys = /* @__PURE__ */ new Set();
    /** Full Sync の上→下パス中の旧順序退避 */
    rebuildBackup = null;
    lastWindow = [];
    /**
     * DB に保存済みの active メッセージ（index 昇順）で初期化する。
     * セッションを跨いだ順序の安定化に使う。dirty にはしない。
     * index の振り直しは行わない（最初の mergeWindow が dirty 付きで揃えるため、
     * DB 内の番号と食い違う中間状態を書き込まずに済む）。
     */
    seed(records) {
      for (const rec of records) {
        if (this.byKey.has(rec.messageKey)) continue;
        this.byKey.set(rec.messageKey, {
          ...rec,
          active: true,
          parts: rec.parts.map((p) => ({ ...p }))
        });
        this.order.push(rec.messageKey);
      }
      this.rebuildPositions();
    }
    /**
     * 画面上の縦位置順（上=古い）に並べたマウント済みウィンドウを取り込む。
     */
    mergeWindow(mounted, options = {}) {
      const stats = {
        added: 0,
        updated: 0,
        unchanged: 0,
        deactivated: 0
      };
      const mountedKeySet = new Set(mounted.map((m) => m.messageKey));
      if (options.displaced && options.displaced.length > 0) {
        const removePositions = [];
        for (const variant of options.displaced) {
          if (mountedKeySet.has(variant.messageKey)) continue;
          const existing = this.byKey.get(variant.messageKey);
          if (existing) {
            if (existing.active) {
              existing.active = false;
              this.dirtyKeys.add(existing.messageKey);
              stats.deactivated++;
            }
          } else {
            this.byKey.set(variant.messageKey, {
              ...variant,
              active: false,
              parts: variant.parts.map((p2) => ({ ...p2 }))
            });
            this.dirtyKeys.add(variant.messageKey);
          }
          const p = this.pos.get(variant.messageKey);
          if (p !== void 0) removePositions.push(p);
        }
        if (removePositions.length > 0) {
          removePositions.sort((a, b) => b - a);
          for (const p of removePositions) this.order.splice(p, 1);
          this.rebuildPositions();
          this.renumber();
        }
      }
      if (mounted.length === 0) return stats;
      for (const incoming of mounted) {
        const existing = this.byKey.get(incoming.messageKey);
        if (existing) {
          if (existing.contentHash !== incoming.contentHash) {
            existing.role = incoming.role;
            existing.speaker = incoming.speaker;
            existing.parts = incoming.parts;
            existing.contentHash = incoming.contentHash;
            existing.updatedAt = incoming.updatedAt;
            this.dirtyKeys.add(existing.messageKey);
            stats.updated++;
          } else {
            stats.unchanged++;
          }
          if (!existing.active) {
            existing.active = true;
            this.dirtyKeys.add(existing.messageKey);
          }
        } else {
          this.byKey.set(incoming.messageKey, {
            ...incoming,
            active: true,
            parts: incoming.parts.map((p) => ({ ...p }))
          });
          this.dirtyKeys.add(incoming.messageKey);
          stats.added++;
        }
      }
      const mountedKeys = mounted.map((m) => m.messageKey);
      if (this.order.length === 0) {
        this.order = [...mountedKeys];
      } else {
        const anchorPositions = [];
        for (const key of mountedKeys) {
          const p = this.pos.get(key);
          if (p !== void 0) anchorPositions.push(p);
        }
        if (anchorPositions.length === 0) {
          if (this.rebuildBackup !== null || options.atBottom) {
            this.order.push(...mountedKeys);
          } else {
            const previousPositions = this.lastWindow.flatMap((key) => {
              const position = this.pos.get(key);
              return position === void 0 ? [] : [position];
            });
            if (options.scrollDirection && previousPositions.length > 0) {
              const insertAt = options.scrollDirection === "older" ? Math.min(...previousPositions) : Math.max(...previousPositions) + 1;
              this.order.splice(insertAt, 0, ...mountedKeys);
            } else {
              this.insertDisjoint(mountedKeys);
            }
          }
        } else {
          let start = Math.min(...anchorPositions);
          let end = Math.max(...anchorPositions);
          if (options.atBottom) {
            end = this.order.length - 1;
          }
          const mountedSet = new Set(mountedKeys);
          for (let i = start; i <= end; i++) {
            const key = this.order[i];
            if (!mountedSet.has(key)) {
              const rec = this.byKey.get(key);
              if (rec && rec.active) {
                rec.active = false;
                this.dirtyKeys.add(key);
                stats.deactivated++;
              }
            }
          }
          this.order.splice(start, end - start + 1, ...mountedKeys);
        }
      }
      this.rebuildPositions();
      this.renumber();
      this.lastWindow = mountedKeys;
      return stats;
    }
    /**
     * Full Sync の上→下パス開始時に呼ぶ。順序リストを空にして
     * パス中の mergeWindow が純粋な遭遇順で再構築できるようにする。
     * メッセージ本体 (byKey) は保持する。
     */
    beginRebuild() {
      if (this.rebuildBackup !== null) return;
      this.rebuildBackup = this.order;
      this.lastWindow = [];
      this.order = [];
      this.rebuildPositions();
    }
    /**
     * Full Sync 終了時（中断時も必ず）に呼ぶ。
     * パス中に遭遇しなかった active な既知メッセージ
     * を旧順序の隣接アンカーに沿って戻す。ID の大小は使用しない。
     */
    finishRebuild() {
      this.lastWindow = [];
      const backup = this.rebuildBackup;
      if (backup === null) return;
      this.rebuildBackup = null;
      let pending = [];
      let previousAnchor = null;
      for (const key of backup) {
        if (!this.byKey.get(key)?.active) continue;
        const position = this.pos.get(key);
        if (position === void 0) {
          pending.push(key);
          continue;
        }
        if (pending.length > 0) {
          this.order.splice(position, 0, ...pending);
          this.rebuildPositions();
          pending = [];
        }
        previousAnchor = key;
      }
      if (pending.length > 0) {
        const insertAt = previousAnchor === null ? 0 : this.pos.get(previousAnchor) + 1;
        this.order.splice(insertAt, 0, ...pending);
      }
      this.rebuildPositions();
      this.renumber();
    }
    /** active なメッセージを時系列順で返す。 */
    getActiveSorted() {
      const out = [];
      for (const key of this.order) {
        const rec = this.byKey.get(key);
        if (rec && rec.active) out.push(rec);
      }
      return out;
    }
    /** 前回 drain 以降に追加・更新・番号変更・無効化されたレコードを返す。 */
    drainDirty() {
      const out = [];
      for (const key of this.dirtyKeys) {
        const rec = this.byKey.get(key);
        if (rec) out.push({ ...rec, parts: rec.parts.map((p) => ({ ...p })) });
      }
      this.dirtyKeys.clear();
      return out;
    }
    /** 送信失敗時に dirty へ戻す。 */
    markDirty(records) {
      for (const rec of records) {
        if (this.byKey.has(rec.messageKey)) this.dirtyKeys.add(rec.messageKey);
      }
    }
    hasDirty() {
      return this.dirtyKeys.size > 0;
    }
    get size() {
      return this.byKey.size;
    }
    get activeCount() {
      return this.order.length;
    }
    clear() {
      this.lastWindow = [];
      this.byKey.clear();
      this.order = [];
      this.pos.clear();
      this.dirtyKeys.clear();
      this.rebuildBackup = null;
    }
    /* ------------------------------------------------------------------ */
    rebuildPositions() {
      this.pos.clear();
      for (let i = 0; i < this.order.length; i++) {
        this.pos.set(this.order[i], i);
      }
    }
    /** order 上の位置 (1-based) を index として振り直す。変更分は dirty。 */
    renumber() {
      for (let i = 0; i < this.order.length; i++) {
        const rec = this.byKey.get(this.order[i]);
        if (!rec) continue;
        const next = i + 1;
        if (rec.index !== next) {
          rec.index = next;
          this.dirtyKeys.add(rec.messageKey);
        }
      }
    }
    insertDisjoint(mountedKeys) {
      const myId = numericIdOf(mountedKeys[0]);
      let insertAt = this.order.length;
      if (myId !== null) {
        for (let i = 0; i < this.order.length; i++) {
          const otherId = numericIdOf(this.order[i]);
          if (otherId !== null && compareNumericIds(otherId, myId) > 0) {
            insertAt = i;
            break;
          }
        }
      }
      this.order.splice(insertAt, 0, ...mountedKeys);
    }
  };
  function numericIdOf(messageKey) {
    const m = /(\d{6,})/.exec(messageKey);
    return m ? m[1] : null;
  }
  function compareNumericIds(a, b) {
    if (a.length !== b.length) return a.length - b.length;
    return a < b ? -1 : a > b ? 1 : 0;
  }

  // src/lorebook/markdown.ts
  function parseLoreMarkdown(source) {
    const lines = source.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n").split("\n");
    const sections = [];
    for (const line of lines) {
      const heading = /^##[ \t]+(.+?)\s*$/.exec(line);
      if (heading) sections.push({ title: heading[1], lines: [] });
      else if (sections.length) sections[sections.length - 1].lines.push(line);
      else if (line.trim() && !/^#\s+/.test(line)) throw new Error("\u672C\u6587\u306F\u300C## \u984C\u540D\u300D\u304B\u3089\u59CB\u3081\u3066\u304F\u3060\u3055\u3044\u3002");
    }
    if (!sections.length || sections.length > 50) throw new Error("\u9805\u76EE\u6570\u306F1\u301C50\u4EF6\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
    return sections.map((section, i) => {
      while (section.lines.length && !section.lines[0].trim()) section.lines.shift();
      const keywordLine = /^キーワード[：:][ \t]*(.*)$/.exec(section.lines.shift() ?? "");
      if (!keywordLine) throw new Error(`\u9805\u76EE${i + 1}: \u984C\u540D\u306E\u6B21\u306B\u300C\u30AD\u30FC\u30EF\u30FC\u30C9: \u2026\u300D\u3092\u8A18\u8FF0\u3057\u3066\u304F\u3060\u3055\u3044\u3002`);
      const entry = {
        title: section.title,
        keywords: keywordLine[1].split(/[,、]/).map((s) => s.trim()).filter(Boolean),
        content: section.lines.join("\n").trim()
      };
      validateLoreEntry(entry, i + 1);
      return entry;
    });
  }
  function validateLoreEntry(entry, number) {
    const fail = (message) => {
      throw new Error(`\u9805\u76EE${number}: ${message}`);
    };
    if (!entry.title.trim() || entry.title.length > 20) fail("\u984C\u540D\u306F1\u301C20\u6587\u5B57\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
    if (!entry.keywords.length || entry.keywords.length > 5 || entry.keywords.some((k) => !k.trim() || k.length > 20)) {
      fail("\u30AD\u30FC\u30EF\u30FC\u30C9\u306F\u54041\u301C20\u6587\u5B57\u30011\u301C5\u500B\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
    }
    if (!entry.content.trim() || entry.content.length > 500) fail("\u5185\u5BB9\u306F1\u301C500\u6587\u5B57\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
  }

  // src/lorebook/form.ts
  var ROW = '[data-sentry-component="LorebookItemRow"]';
  var rows = (root) => Array.from(root.querySelectorAll(ROW));
  var field = (row, key) => row.querySelector(`[name^="items."][name$=".${key}"]`);
  function findLorebookRoot(doc = document) {
    const matches = Array.from(doc.querySelectorAll(ROW)).map((r) => r.parentElement?.parentElement);
    return matches.find((root) => root && findAddButton(root)) ?? null;
  }
  function findAddButton(root) {
    return Array.from(root.querySelectorAll("button")).find((button) => /^\+?\s*項目追加\s*[（(]/.test(button.textContent?.trim() ?? ""));
  }
  async function fillLorebook(root, entries, onProgress = () => {
  }, signal) {
    if (!entries.length || entries.length > 50) throw new Error("\u9805\u76EE\u6570\u306F1\u301C50\u4EF6\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
    entries.forEach((entry, i) => validateLoreEntry(entry, i + 1));
    const initialUrl = root.ownerDocument.location.href;
    const check = () => {
      if (signal?.aborted) throw new Error("\u5165\u529B\u3092\u4E2D\u6B62\u3057\u307E\u3057\u305F\u3002\u5165\u529B\u6E08\u307F\u306E\u9805\u76EE\u306F\u6B8B\u3063\u3066\u3044\u307E\u3059\u3002");
      if (!root.isConnected || root.ownerDocument.location.href !== initialUrl) throw new Error("\u7DE8\u96C6\u753B\u9762\u304C\u5909\u308F\u3063\u305F\u305F\u3081\u505C\u6B62\u3057\u307E\u3057\u305F\u3002");
    };
    const wait = async (condition) => {
      const deadline = Date.now() + 3e3;
      while (true) {
        check();
        if (condition()) return;
        if (Date.now() >= deadline) throw new Error("\u5165\u529B\u6B04\u306E\u8868\u793A\u5F85\u3061\u304C\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8\u3057\u307E\u3057\u305F\u3002");
        await new Promise((resolve) => setTimeout(resolve, 40));
      }
    };
    const open = async (index) => {
      check();
      const row = rows(root)[index];
      if (!row) throw new Error("\u9805\u76EE\u306E\u69CB\u9020\u304C\u5909\u308F\u308A\u307E\u3057\u305F\u3002");
      if (!field(row, "name")) {
        const toggle = row.querySelector('button[data-sentry-element="RawButton"]');
        if (!toggle) throw new Error("\u9805\u76EE\u3092\u5C55\u958B\u3059\u308B\u30DC\u30BF\u30F3\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002");
        toggle.click();
      }
      await wait(() => ["name", "keywords", "content"].every((key) => !!field(rows(root)[index], key)));
    };
    const read = (index) => ["name", "keywords", "content"].map((key) => field(rows(root)[index], key)?.value ?? "");
    const empty = (values) => values.every((value) => value === "");
    const originalCount = rows(root).length;
    if (originalCount > 50) throw new Error("\u753B\u9762\u306E\u9805\u76EE\u6570\u304C\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\u3002");
    const blanks = [];
    const original = [];
    for (let i = 0; i < originalCount; i++) {
      await open(i);
      const values = read(i);
      original.push(values);
      if (empty(values)) blanks.push(i);
    }
    if (entries.length > blanks.length + 50 - originalCount) throw new Error("\u5165\u529B\u6E08\u307F\u9805\u76EE\u3092\u6B8B\u3059\u306850\u4EF6\u3092\u8D85\u3048\u307E\u3059\u3002\u30D5\u30A1\u30A4\u30EB\u306E\u9805\u76EE\u6570\u3092\u6E1B\u3089\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
    onProgress(0, entries.length);
    const expected = /* @__PURE__ */ new Map();
    original.forEach((values, i) => expected.set(i, values));
    const verify = async () => {
      for (const [index, values] of expected) {
        await open(index);
        if (JSON.stringify(read(index)) !== JSON.stringify(values)) throw new Error("\u753B\u9762\u306E\u5165\u529B\u5185\u5BB9\u304C\u5909\u308F\u3063\u305F\u305F\u3081\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u5165\u529B\u7D50\u679C\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
      }
    };
    let count = originalCount;
    for (let i = 0; i < entries.length; i++) {
      check();
      if (rows(root).length !== count) throw new Error("\u9805\u76EE\u6570\u304C\u5909\u308F\u3063\u305F\u305F\u3081\u505C\u6B62\u3057\u307E\u3057\u305F\u3002");
      let index = blanks[i];
      if (index === void 0) {
        const add = findAddButton(root);
        if (!add || add.disabled || count >= 50) throw new Error("\u9805\u76EE\u3092\u8FFD\u52A0\u3067\u304D\u307E\u305B\u3093\u3002");
        add.click();
        await wait(() => rows(root).length === count + 1);
        index = count++;
      }
      await open(index);
      if (!empty(read(index))) throw new Error("\u5165\u529B\u5148\u306B\u65E2\u5B58\u306E\u5185\u5BB9\u304C\u3042\u308B\u305F\u3081\u505C\u6B62\u3057\u307E\u3057\u305F\u3002");
      const values = [entries[i].title, entries[i].keywords.join("\u3001"), entries[i].content];
      for (const [n, key] of ["name", "keywords", "content"].entries()) {
        check();
        const input = field(rows(root)[index], key);
        if (input.disabled || input.readOnly) throw new Error("\u5165\u529B\u6B04\u304C\u7DE8\u96C6\u3067\u304D\u307E\u305B\u3093\u3002");
        const proto = input.tagName === "INPUT" ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
        Object.getOwnPropertyDescriptor(proto, "value").set.call(input, values[n]);
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
        input.dispatchEvent(new FocusEvent("blur", { bubbles: true }));
        input.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
        await new Promise((resolve) => setTimeout(resolve, 40));
        check();
        if (field(rows(root)[index], key)?.value !== values[n]) throw new Error("\u5165\u529B\u304C\u753B\u9762\u306B\u53CD\u6620\u3055\u308C\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u51E6\u7406\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002");
      }
      expected.set(index, values);
      onProgress(i + 1, entries.length);
    }
    await verify();
  }

  // src/lorebook/importer.ts
  function startLorebookImporter() {
    const mount = () => {
      const root = findLorebookRoot();
      if (!root || root.querySelector("[data-zlc-lore-import]")) return;
      const host = document.createElement("div");
      host.setAttribute("data-zlc-lore-import", "");
      const shadow = host.attachShadow({ mode: "open" });
      shadow.innerHTML = `<style>
      :host{display:block;margin:12px 0;color:#eee;font:14px/1.5 system-ui}
      details{background:#222;border:1px solid #555;border-radius:10px;padding:12px}
      summary{cursor:pointer;font-weight:600}button,input{font:inherit;max-width:100%}
      button{padding:8px 12px;border:1px solid #777;border-radius:6px;background:#333;color:white;cursor:pointer;margin:4px}
      button:disabled{opacity:.45;cursor:default}pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:240px;overflow:auto;background:#171717;padding:10px}
      p{margin:10px 0}input{display:block}button:focus-visible,summary:focus-visible{outline:2px solid #8bf}
    </style><details><summary>Markdown\u304B\u3089\u30ED\u30A2\u30D6\u30C3\u30AF\u3092\u53D6\u308A\u8FBC\u3080</summary>
    <p>\u5165\u529B\u6E08\u307F\u9805\u76EE\u3092\u6B8B\u3057\u3001\u7A7A\u6B04\u3092\u5229\u7528\u3057\u3066\u8FFD\u52A0\u3057\u307E\u3059\u3002\u767B\u9332\u30FB\u5B8C\u6210\u306F\u5165\u529B\u5F8C\u306B\u884C\u3063\u3066\u304F\u3060\u3055\u3044\u3002</p>
    <label>Markdown\u30D5\u30A1\u30A4\u30EB<input type="file" accept=".md,.markdown,text/markdown,text/plain"></label>
    <p>\u66F8\u5F0F\uFF1A## \u984C\u540D \u2192 \u30AD\u30FC\u30EF\u30FC\u30C9: \u5358\u8A9E\u3001\u5358\u8A9E \u2192 \u7A7A\u884C\u3068\u672C\u6587</p>
    <pre hidden></pre><p role="status" aria-live="polite"></p>
    <button data-action="fill" disabled>\u78BA\u8A8D\u3057\u305F\u5185\u5BB9\u3092\u5165\u529B\u3059\u308B</button><button data-action="cancel" hidden>\u4E2D\u6B62</button>
    </details>`;
      const file = shadow.querySelector("input");
      const preview = shadow.querySelector("pre");
      const status = shadow.querySelector('[role="status"]');
      const fill = shadow.querySelector('[data-action="fill"]');
      const cancel = shadow.querySelector('[data-action="cancel"]');
      let entries = [];
      let controller = null;
      let selection = 0;
      file.addEventListener("change", async () => {
        const ticket = ++selection;
        fill.disabled = true;
        entries = [];
        preview.hidden = true;
        status.textContent = "";
        try {
          const selected = file.files?.[0];
          if (!selected) return;
          if (selected.size > 1024 * 1024) throw new Error("\u30D5\u30A1\u30A4\u30EB\u306F1MB\u4EE5\u4E0B\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
          const source = await selected.text();
          if (ticket !== selection) return;
          entries = parseLoreMarkdown(source);
          preview.textContent = entries.map((entry, i) => `${i + 1}. ${entry.title}
\u30AD\u30FC\u30EF\u30FC\u30C9: ${entry.keywords.join("\u3001")}
${entry.content}`).join("\n\n");
          preview.hidden = false;
          status.textContent = `${entries.length}\u4EF6\u3092\u8AAD\u307F\u8FBC\u307F\u307E\u3057\u305F\u3002\u5185\u5BB9\u3092\u78BA\u8A8D\u3057\u3066\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002`;
          fill.disabled = false;
        } catch (error) {
          status.textContent = error instanceof Error ? error.message : String(error);
        }
      });
      cancel.addEventListener("click", () => controller?.abort());
      fill.addEventListener("click", async () => {
        fill.disabled = true;
        file.disabled = true;
        cancel.hidden = false;
        controller = new AbortController();
        status.textContent = "\u7A7A\u6B04\u3068\u9805\u76EE\u6570\u3092\u78BA\u8A8D\u3057\u3066\u3044\u307E\u3059\u3002\u5165\u529B\u4E2D\u306F\u7DE8\u96C6\u753B\u9762\u3092\u64CD\u4F5C\u305B\u305A\u304A\u5F85\u3061\u304F\u3060\u3055\u3044\u3002";
        try {
          await fillLorebook(root, entries, (done, total) => {
            status.textContent = `\u5165\u529B\u4E2D: ${done}/${total}\u4EF6\u3002\u7DE8\u96C6\u753B\u9762\u3092\u64CD\u4F5C\u305B\u305A\u304A\u5F85\u3061\u304F\u3060\u3055\u3044\u3002`;
          }, controller.signal);
          status.textContent = `${entries.length}\u4EF6\u306E\u5165\u529B\u3092\u78BA\u8A8D\u3057\u307E\u3057\u305F\u3002Zeta\u4E0A\u3067\u78BA\u8A8D\u3057\u3001\u767B\u9332\u3057\u3066\u304F\u3060\u3055\u3044\u3002`;
        } catch (error) {
          status.textContent = `${error instanceof Error ? error.message : String(error)} \u5165\u529B\u6E08\u307F\u306E\u6B04\u306F\u6B8B\u3063\u3066\u3044\u307E\u3059\u3002\u518D\u5B9F\u884C\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002`;
        } finally {
          file.disabled = false;
          cancel.hidden = true;
          controller = null;
        }
      });
      root.prepend(host);
    };
    mount();
    window.setInterval(mount, 1e3);
  }

  // src/content/speaker-shortcuts.ts
  function startSpeakerShortcuts(doc = document) {
    const styleId = "zm-speaker-shortcuts";
    if (doc.getElementById(styleId)) return () => {
    };
    const style = doc.createElement("style");
    style.id = styleId;
    style.textContent = "[data-zm-speaker-selected]{outline:2px solid #7aa2ff!important;outline-offset:-2px}";
    doc.head.append(style);
    const clear = () => doc.querySelectorAll("[data-zm-speaker-selected]").forEach((element) => element.removeAttribute("data-zm-speaker-selected"));
    const visible = (element) => !element.closest('[hidden],[inert],[aria-hidden="true"]') && element.getClientRects().length > 0 && getComputedStyle(element).visibility !== "hidden";
    const keydown = (event) => {
      if (event.isComposing || event.keyCode === 229 || event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) return;
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      const composer = target.closest('[data-sentry-component="ChatComposer"]');
      if (!composer) return;
      const input = composer.querySelector('textarea[name="message"]');
      const strip = composer.querySelector('[data-sentry-component="SpeakerRecommendationStrip"]');
      if (!input || input.disabled || input.readOnly || !strip || !visible(strip)) return;
      const buttons = Array.from(strip.querySelectorAll('button[data-sentry-component="LogRawButton"]')).filter((button2) => !button2.disabled && button2.getAttribute("aria-disabled") !== "true" && visible(button2));
      const current = buttons.indexOf(target);
      if (target !== input && current < 0) return;
      let index;
      let activate = false;
      if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        if (!buttons.length) return;
        index = current < 0 ? event.key === "ArrowRight" ? 0 : buttons.length - 1 : (current + (event.key === "ArrowRight" ? 1 : -1) + buttons.length) % buttons.length;
      } else if (/^[0-9]$/.test(event.key) && /^(Digit|Numpad)[0-9]$/.test(event.code)) {
        index = event.key === "0" ? 9 : Number(event.key) - 1;
        activate = true;
      } else if (event.key === "Enter" && current >= 0) {
        index = current;
        activate = true;
      } else return;
      const button = buttons[index];
      if (!button) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      if (activate && event.repeat) return;
      clear();
      if (activate) {
        button.click();
        if (input.isConnected) input.focus({ preventScroll: true });
      } else {
        button.setAttribute("data-zm-speaker-selected", "");
        button.focus({ preventScroll: true });
        button.scrollIntoView?.({ block: "nearest", inline: "nearest" });
      }
    };
    const host = doc.defaultView;
    host.addEventListener("keydown", keydown, true);
    doc.addEventListener("pointerdown", clear, true);
    return () => {
      host.removeEventListener("keydown", keydown, true);
      doc.removeEventListener("pointerdown", clear, true);
      clear();
      style.remove();
    };
  }

  // src/shared/utils.ts
  function countChars(text) {
    let n = 0;
    for (const _ of text) n++;
    return n;
  }
  function fnv1a(input) {
    let hash = 2166136261;
    for (let i = 0; i < input.length; i++) {
      hash ^= input.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }
  function formatTimeLocal(timestamp) {
    const d = new Date(timestamp);
    const h = String(d.getHours()).padStart(2, "0");
    const min = String(d.getMinutes()).padStart(2, "0");
    return `${h}:${min}`;
  }
  function debounce(fn, waitMs) {
    let timer = null;
    let lastArgs = null;
    const debounced = (...args) => {
      lastArgs = args;
      if (timer !== null) clearTimeout(timer);
      timer = setTimeout(() => {
        timer = null;
        const a = lastArgs;
        lastArgs = null;
        if (a) fn(...a);
      }, waitMs);
    };
    debounced.cancel = () => {
      if (timer !== null) clearTimeout(timer);
      timer = null;
      lastArgs = null;
    };
    debounced.flush = () => {
      if (timer !== null) {
        clearTimeout(timer);
        timer = null;
        const a = lastArgs;
        lastArgs = null;
        if (a) fn(...a);
      }
    };
    return debounced;
  }
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function isLocalEndpoint(url) {
    try {
      const u = new URL(url);
      return u.hostname === "localhost" || u.hostname === "127.0.0.1" || u.hostname === "[::1]" || u.hostname === "::1";
    } catch {
      return false;
    }
  }

  // src/content/zeta-adapter.ts
  var ZETA_SELECTORS = {
    plotName: '[data-testid="chat-header-profile"]',
    logContainer: '[role="log"][aria-label="Chat messages"]',
    logContainerFallback: '[role="log"]',
    messageNodes: '[data-key^="message-"][data-index]',
    chat: ".chat",
    userContent: '[data-sentry-component="RightTextContent"]',
    aiContent: '[data-sentry-component="LeftTextContent"]',
    narration: '[data-sentry-component="NarratorBubble"]',
    speaker: "span.caption1"
  };
  var ROOM_PATH_RE = /^(?:\/[A-Za-z0-9-]+)?\/rooms\/([0-9a-fA-F-]{8,64})(?:\/|$)/;
  function getRoomId(pathname) {
    const p = pathname ?? (typeof location !== "undefined" ? location.pathname : "");
    const m = ROOM_PATH_RE.exec(p);
    return m ? m[1] : null;
  }
  function getPlotName(root = document) {
    const el = root.querySelector(ZETA_SELECTORS.plotName);
    const text = el?.textContent?.trim();
    return text ? text : null;
  }
  function findLogContainer(root = document) {
    const strict = root.querySelector(ZETA_SELECTORS.logContainer);
    if (strict) return strict;
    return root.querySelector(ZETA_SELECTORS.logContainerFallback);
  }
  function findMessageNodes(root = document) {
    const container = findLogContainer(root) ?? root;
    const nodes = Array.from(
      container.querySelectorAll(ZETA_SELECTORS.messageNodes)
    );
    return nodes.filter(
      (n) => (n.getAttribute("data-key") ?? "").startsWith("message-")
    );
  }
  function parseMessage(node, roomId, now = Date.now()) {
    const messageKey = node.getAttribute("data-key");
    const indexRaw = node.getAttribute("data-index");
    if (!messageKey || !messageKey.startsWith("message-")) return null;
    if (indexRaw === null) return null;
    const index = Number.parseInt(indexRaw, 10);
    if (!Number.isFinite(index)) return null;
    const parts = [];
    const chats = Array.from(node.querySelectorAll(ZETA_SELECTORS.chat));
    for (const chat of chats) {
      const text = extractText(chat);
      if (!text) continue;
      if (chat.closest(ZETA_SELECTORS.narration)) {
        parts.push({ type: "narration", text });
        continue;
      }
      const userContainer = chat.closest(ZETA_SELECTORS.userContent);
      if (userContainer) {
        const speaker2 = findSpeaker(userContainer);
        parts.push(speaker2 ? { type: "user", speaker: speaker2, text } : { type: "user", text });
        continue;
      }
      const aiContainer = chat.closest(ZETA_SELECTORS.aiContent);
      if (aiContainer) {
        const speaker2 = findSpeaker(aiContainer);
        parts.push(
          speaker2 ? { type: "character", speaker: speaker2, text } : { type: "character", text }
        );
        continue;
      }
      if (looksRightAligned(chat, node)) {
        parts.push({ type: "user", text });
      } else {
        parts.push({ type: "character", text });
      }
    }
    if (parts.length === 0) return null;
    const role = parts.some((p) => p.type === "user") ? "user" : "ai";
    const speaker = parts.find((p) => p.speaker)?.speaker ?? findSpeaker(node) ?? null;
    return {
      roomId,
      messageKey,
      index,
      role,
      speaker,
      parts,
      capturedAt: now,
      updatedAt: now,
      contentHash: hashContent(role, parts),
      active: true
    };
  }
  function hashContent(role, parts) {
    const canonical = JSON.stringify([
      role,
      parts.map((p) => [p.type, p.speaker ?? "", p.text])
    ]);
    return fnv1a(canonical);
  }
  function findSpeaker(scope) {
    const el = scope.querySelector(ZETA_SELECTORS.speaker);
    const text = el?.textContent?.trim();
    return text ? text : null;
  }
  function looksRightAligned(chat, boundary) {
    let el = chat;
    while (el && el !== boundary.parentElement) {
      const cls = el.getAttribute("class") ?? "";
      if (/(?:^|\s)(?:items-end|justify-end|self-end|text-right)(?:\s|$)/.test(cls)) {
        return true;
      }
      if (el === boundary) break;
      el = el.parentElement;
    }
    return false;
  }
  function extractText(el) {
    const maybe = el.innerText;
    const raw = typeof maybe === "string" && maybe.length > 0 ? maybe : fallbackInnerText(el);
    return normalizeText(raw);
  }
  var SKIP_TAGS = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "NOSCRIPT",
    "TEMPLATE",
    "BUTTON",
    "IMG",
    "SVG",
    "AUDIO",
    "VIDEO",
    "INPUT",
    "TEXTAREA",
    "SELECT"
  ]);
  var BLOCK_TAGS = /* @__PURE__ */ new Set([
    "P",
    "DIV",
    "SECTION",
    "ARTICLE",
    "LI",
    "UL",
    "OL",
    "BLOCKQUOTE",
    "PRE",
    "TR",
    "TABLE",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "HEADER",
    "FOOTER",
    "FIGURE",
    "HR"
  ]);
  function fallbackInnerText(root) {
    let out = "";
    const ensureBreaks = (count) => {
      if (out.length === 0) return;
      let trailing = 0;
      while (trailing < out.length && out[out.length - 1 - trailing] === "\n") {
        trailing++;
      }
      for (let i = trailing; i < count; i++) out += "\n";
    };
    const walk = (node) => {
      if (node.nodeType === 3) {
        out += node.nodeValue ?? "";
        return;
      }
      if (node.nodeType !== 1) return;
      const el = node;
      const tag = el.tagName.toUpperCase();
      if (SKIP_TAGS.has(tag)) return;
      if (el.getAttribute("aria-hidden") === "true") return;
      if (tag === "BR") {
        out += "\n";
        return;
      }
      const isBlock = BLOCK_TAGS.has(tag);
      const breaks = tag === "P" ? 2 : isBlock ? 1 : 0;
      if (breaks > 0) ensureBreaks(breaks);
      for (const child of Array.from(node.childNodes)) walk(child);
      if (breaks > 0) ensureBreaks(breaks);
    };
    for (const child of Array.from(root.childNodes)) walk(child);
    return out;
  }
  function normalizeText(raw) {
    return raw.replace(/\r\n?/g, "\n").replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  // src/content/capture-window.ts
  function captureVisibleWindow(roomId) {
    const now = Date.now();
    const entries = [];
    for (const node of findMessageNodes()) {
      try {
        const rec = parseMessage(node, roomId, now);
        if (!rec) continue;
        const rect = node.getBoundingClientRect();
        entries.push({
          rec,
          top: rect.top,
          height: rect.height,
          centerX: rect.left + rect.width / 2,
          domOrder: entries.length
        });
      } catch (e) {
        console.warn("[ZetaLogCompanion] parseMessage failed:", e);
      }
    }
    const hasLayout = entries.some((e) => e.height > 0);
    if (!hasLayout) {
      entries.sort(
        (a, b) => a.rec.index !== b.rec.index ? a.rec.index - b.rec.index : a.domOrder - b.domOrder
      );
      return { records: entries.map((e) => e.rec), displaced: [] };
    }
    const usable = entries.filter((e) => e.height > 0);
    usable.sort((a, b) => {
      if (Math.abs(a.top - b.top) > 0.5) return a.top - b.top;
      if (a.rec.index !== b.rec.index) return a.rec.index - b.rec.index;
      return a.domOrder - b.domOrder;
    });
    const logRect = findLogContainer()?.getBoundingClientRect();
    const anchorCenterX = logRect && logRect.width > 0 ? logRect.left + logRect.width / 2 : window.innerWidth / 2;
    const partition = partitionVariantSlots(
      usable.map((e) => ({ top: e.top, height: e.height, centerX: e.centerX })),
      anchorCenterX
    );
    return {
      records: partition.visible.map((i) => usable[i].rec),
      displaced: partition.displaced.map((i) => usable[i].rec)
    };
  }

  // src/content/passive-capture.ts
  function batchLiveUpdates(update, waitMs = 120) {
    let timer = null;
    const schedule = () => {
      if (timer !== null) return;
      timer = setTimeout(() => {
        timer = null;
        update();
      }, waitMs);
    };
    schedule.cancel = () => {
      if (timer !== null) clearTimeout(timer);
      timer = null;
    };
    return schedule;
  }
  var PassiveCapture = class {
    constructor(log, scan) {
      this.log = log;
      this.scan = scan;
      this.observer = new MutationObserver(() => this.schedule());
      this.observer.observe(log, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ["data-key", "data-index"]
      });
      log.ownerDocument.addEventListener("scroll", this.onScroll, { capture: true, passive: true });
    }
    frame = null;
    observer;
    stopped = false;
    onScroll = (event) => {
      const target = event.target;
      if (target instanceof HTMLElement && (target.contains(this.log) || this.log.contains(target))) this.schedule();
    };
    schedule() {
      if (this.stopped || this.frame !== null) return;
      this.frame = requestAnimationFrame(() => {
        this.frame = null;
        if (!this.stopped) this.scan();
      });
    }
    stop() {
      this.stopped = true;
      this.observer.disconnect();
      this.log.ownerDocument.removeEventListener("scroll", this.onScroll, true);
      if (this.frame !== null) cancelAnimationFrame(this.frame);
      this.frame = null;
    }
  };
  var CaptureScrollTracker = class {
    previous = null;
    observe(container, keys) {
      if (keys.length === 0) return void 0;
      const signature = JSON.stringify(keys);
      const previous = this.previous;
      if (previous?.container === container && previous.keys === signature) return void 0;
      this.previous = { container, keys: signature, top: container.scrollTop, height: container.scrollHeight };
      if (!previous || previous.container !== container || previous.height !== container.scrollHeight) return void 0;
      const delta = container.scrollTop - previous.top;
      return Math.abs(delta) < 1 ? void 0 : delta < 0 ? "older" : "newer";
    }
    reset() {
      this.previous = null;
    }
  };

  // src/content/full-sync.ts
  function findScrollContainer(log) {
    let el = log;
    while (el && el !== document.body && el !== document.documentElement) {
      if (el.scrollHeight > el.clientHeight + 10) {
        const overflowY = getComputedStyle(el).overflowY;
        if (overflowY === "auto" || overflowY === "scroll" || overflowY === "overlay") {
          return el;
        }
      }
      el = el.parentElement;
    }
    return log;
  }
  function isNearBottom(container, thresholdPx = 80) {
    const style = getComputedStyle(container);
    if (style.flexDirection === "column-reverse") {
      return Math.abs(container.scrollTop) <= thresholdPx;
    }
    return container.scrollHeight - container.clientHeight - container.scrollTop <= thresholdPx;
  }
  async function runFullSync(options) {
    const {
      container,
      collect,
      onProgress,
      shouldAbort = () => false,
      settleMs = 450,
      loadWaitMs = 2500,
      stagnantLimit = 3,
      maxSteps = 600,
      maxTopJumps = 150
    } = options;
    const originalScrollTop = container.scrollTop;
    let steps = 0;
    let collected = 0;
    let collectionFailed = false;
    const safeCollect = () => {
      try {
        collected = Math.max(collected, collect());
      } catch (e) {
        collectionFailed = true;
        console.warn("[ZetaLogCompanion] full-sync collect failed:", e);
      }
      return collected;
    };
    const report = (phase) => {
      onProgress?.({ phase, collectedMessages: collected, steps });
    };
    const jumpToTop = () => {
      container.scrollTop = -1e9;
    };
    const windowSignature = () => {
      if (typeof container.querySelectorAll !== "function") return null;
      const nodes = container.querySelectorAll('[data-key^="message-"][data-index]');
      if (nodes.length === 0) return null;
      return JSON.stringify(Array.from(nodes, (node) => [node.dataset.key, node.textContent]));
    };
    const waitForRender = async (before) => {
      const deadline = Date.now() + settleMs;
      let last = before;
      let changed = false;
      let stableSince = Date.now();
      while (Date.now() < deadline) {
        await sleep(Math.min(40, deadline - Date.now()));
        if (shouldAbort()) return;
        const current = windowSignature();
        if (current !== last) {
          last = current;
          stableSince = Date.now();
          changed = true;
        }
        if (changed && current !== null && Date.now() - stableSince >= 80) return;
      }
    };
    const waitForLoad = async () => {
      const baseHeight = container.scrollHeight;
      const baseTop = container.scrollTop;
      const deadline = Date.now() + loadWaitMs;
      while (Date.now() < deadline) {
        await sleep(Math.min(50, deadline - Date.now()));
        if (shouldAbort()) return false;
        if (container.scrollHeight !== baseHeight || Math.abs(container.scrollTop - baseTop) > 1) {
          let height = container.scrollHeight;
          let top = container.scrollTop;
          let stableSince = Date.now();
          const settleDeadline = Date.now() + settleMs;
          while (Date.now() < settleDeadline) {
            await sleep(Math.min(50, settleDeadline - Date.now()));
            if (shouldAbort()) return false;
            if (height !== container.scrollHeight || Math.abs(top - container.scrollTop) > 1) {
              height = container.scrollHeight;
              top = container.scrollTop;
              stableSince = Date.now();
            }
            if (Date.now() - stableSince >= 100) break;
          }
          return true;
        }
      }
      return false;
    };
    let completed = false;
    try {
      let stagnantA = 0;
      let jumps = 0;
      while (stagnantA < 2 && jumps < maxTopJumps) {
        if (shouldAbort()) break;
        jumpToTop();
        jumps++;
        steps = jumps;
        report("loading");
        const grew = await waitForLoad();
        if (shouldAbort()) break;
        if (grew) {
          stagnantA = 0;
        } else {
          stagnantA++;
        }
      }
      if (!shouldAbort()) {
        const beforeTop = windowSignature();
        jumpToTop();
        await waitForRender(beforeTop);
        let stagnantB = 0;
        let scanSteps = 0;
        while (stagnantB < stagnantLimit && scanSteps < maxSteps) {
          if (shouldAbort()) break;
          const prevCount = collected;
          safeCollect();
          report("scanning");
          const before = container.scrollTop;
          const beforeWindow = windowSignature();
          container.scrollTop = before + Math.max(120, container.clientHeight * 0.6);
          steps++;
          scanSteps++;
          await waitForRender(beforeWindow);
          if (shouldAbort()) break;
          const after = container.scrollTop;
          const moved = Math.abs(after - before) >= 1;
          const grew = collected > prevCount;
          if (!moved && !grew) {
            stagnantB++;
          } else {
            stagnantB = 0;
          }
        }
        if (!shouldAbort()) {
          safeCollect();
          completed = stagnantA >= 2 && stagnantB >= stagnantLimit && !collectionFailed;
        }
      }
    } finally {
      report("restoring");
      try {
        container.scrollTop = originalScrollTop;
        await sleep(Math.min(settleMs, 300));
        container.scrollTop = originalScrollTop + 1;
        await sleep(80);
        container.scrollTop = originalScrollTop;
        await sleep(Math.min(settleMs, 300));
      } catch (e) {
        console.warn("[ZetaLogCompanion] full-sync scroll restore failed:", e);
      }
    }
    if (!completed) {
      report("aborted");
      return { aborted: true, collectedMessages: collected, steps };
    }
    report("done");
    return { aborted: false, collectedMessages: collected, steps };
  }

  // src/content/panel.css
  var panel_default = '/* zeta-manager panel \u2014 Shadow DOM \u5185\u306E\u307F\u3067\u9069\u7528 (\xA717 / \xA719) */\n\n:host {\n  all: initial;\n}\n\n* {\n  box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n}\n\n/* hidden \u5C5E\u6027\u304C display \u6307\u5B9A (class / inline) \u306B\u8CA0\u3051\u306A\u3044\u3088\u3046\u306B\u3059\u308B */\n[hidden] {\n  display: none !important;\n}\n\n.zlc-root {\n  --bg: #14161a;\n  --bg-2: #1c2027;\n  --bg-3: #242a33;\n  --border: #313845;\n  --text: #e7e9ee;\n  --muted: #9aa3b2;\n  --accent: #7aa2ff;\n  --accent-2: #2e4a8f;\n  --ok: #5dd39e;\n  --warn: #ffcf6b;\n  --danger: #ff7a7a;\n\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  width: 100%;\n  height: 100%;\n  background: var(--bg);\n  color: var(--text);\n  font-family: "Hiragino Kaku Gothic ProN", "Noto Sans JP", "Yu Gothic UI",\n    Meiryo, system-ui, sans-serif;\n  font-size: 12.5px;\n  line-height: 1.55;\n  border-left: 1px solid var(--border);\n}\n\n.zlc-resize-handle {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 5px;\n  height: 100%;\n  cursor: ew-resize;\n  z-index: 10;\n}\n.zlc-resize-handle:hover {\n  background: var(--accent-2);\n}\n\n.zlc-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  padding: 8px 10px 8px 12px;\n  border-bottom: 1px solid var(--border);\n  background: var(--bg-2);\n  flex: none;\n}\n\n.zlc-title {\n  font-weight: 700;\n  font-size: 12px;\n  letter-spacing: 0.04em;\n  color: var(--muted);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\nbutton.zlc-icon-btn {\n  flex: none;\n  width: 24px;\n  height: 24px;\n  border: 1px solid var(--border);\n  border-radius: 5px;\n  background: var(--bg-3);\n  color: var(--text);\n  cursor: pointer;\n  font-size: 12px;\n  line-height: 1;\n}\nbutton.zlc-icon-btn:hover {\n  border-color: var(--accent);\n}\n\n.zlc-tabs {\n  display: flex;\n  border-bottom: 1px solid var(--border);\n  background: var(--bg-2);\n  flex: none;\n}\n.zlc-tabs button {\n  flex: 1 1 0;\n  padding: 7px 2px;\n  background: none;\n  border: none;\n  border-bottom: 2px solid transparent;\n  color: var(--muted);\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.06em;\n  cursor: pointer;\n}\n.zlc-tabs button:hover {\n  color: var(--text);\n}\n.zlc-tabs button.active {\n  color: var(--accent);\n  border-bottom-color: var(--accent);\n}\n\n.zlc-panel {\n  flex: 1 1 auto;\n  min-height: 0;\n  display: flex;\n  flex-direction: column;\n  overflow-y: auto;\n  padding: 10px 12px;\n  gap: 10px;\n}\n\n.zlc-global-status {\n  flex: none;\n  padding: 6px 12px;\n  font-size: 11.5px;\n  border-bottom: 1px solid var(--border);\n}\n.zlc-global-status.error {\n  color: var(--danger);\n}\n.zlc-global-status.info {\n  color: var(--warn);\n}\n\n/* ---- LIVE ---- */\n\n.zlc-plot-name {\n  font-size: 15px;\n  font-weight: 700;\n  word-break: break-all;\n}\n\n.zlc-live-stats {\n  color: var(--muted);\n  font-size: 12px;\n}\n\n.zlc-save-row {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 11.5px;\n  color: var(--muted);\n}\n\n.zlc-badge {\n  display: inline-block;\n  padding: 1px 7px;\n  border-radius: 999px;\n  border: 1px solid var(--border);\n  font-size: 10.5px;\n  font-weight: 700;\n  letter-spacing: 0.03em;\n}\n.zlc-badge.on {\n  color: var(--ok);\n  border-color: var(--ok);\n}\n.zlc-badge.off {\n  color: var(--muted);\n}\n.zlc-badge.local {\n  color: var(--ok);\n  border-color: var(--ok);\n}\n.zlc-badge.remote {\n  color: var(--warn);\n  border-color: var(--warn);\n}\n\n.zlc-btn-row {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n\nbutton.zlc-btn {\n  padding: 5px 10px;\n  border: 1px solid var(--border);\n  border-radius: 6px;\n  background: var(--bg-3);\n  color: var(--text);\n  font-size: 12px;\n  cursor: pointer;\n  white-space: nowrap;\n}\nbutton.zlc-btn:hover:not(:disabled) {\n  border-color: var(--accent);\n}\nbutton.zlc-btn:disabled {\n  opacity: 0.5;\n  cursor: default;\n}\nbutton.zlc-btn.primary {\n  background: var(--accent-2);\n  border-color: var(--accent-2);\n}\nbutton.zlc-btn.primary:hover:not(:disabled) {\n  border-color: var(--accent);\n}\nbutton.zlc-btn.danger:hover:not(:disabled) {\n  border-color: var(--danger);\n  color: var(--danger);\n}\n\n.zlc-sync-progress {\n  padding: 6px 8px;\n  border: 1px solid var(--accent-2);\n  border-radius: 6px;\n  background: rgba(122, 162, 255, 0.08);\n  color: var(--accent);\n  font-size: 11.5px;\n}\n\ntextarea.zlc-textarea {\n  flex: 1 1 auto;\n  min-height: 120px;\n  width: 100%;\n  resize: vertical;\n  padding: 8px;\n  border: 1px solid var(--border);\n  border-radius: 6px;\n  background: var(--bg-2);\n  color: var(--text);\n  font-family: inherit;\n  font-size: 12px;\n  line-height: 1.6;\n}\ntextarea.zlc-textarea:focus {\n  outline: 1px solid var(--accent-2);\n}\n\n/* ---- ARCHIVES ---- */\n\n.zlc-archive-item {\n  padding: 8px 10px;\n  border: 1px solid var(--border);\n  border-radius: 7px;\n  background: var(--bg-2);\n  cursor: pointer;\n}\n.zlc-archive-item:hover {\n  border-color: var(--accent);\n}\n.zlc-archive-item .name {\n  font-weight: 700;\n  word-break: break-all;\n}\n.zlc-archive-item .meta {\n  color: var(--muted);\n  font-size: 11px;\n  margin-top: 2px;\n}\n\n.zlc-empty {\n  color: var(--muted);\n  text-align: center;\n  padding: 18px 0;\n}\n\n.zlc-detail-meta {\n  color: var(--muted);\n  font-size: 11.5px;\n}\n\n.zlc-summary-item {\n  padding: 7px 9px;\n  border: 1px solid var(--border);\n  border-radius: 7px;\n  background: var(--bg-2);\n}\n.zlc-summary-item .meta {\n  color: var(--muted);\n  font-size: 10.5px;\n  margin-bottom: 4px;\n}\n.zlc-summary-item .body {\n  white-space: pre-wrap;\n  word-break: break-word;\n  font-size: 11.5px;\n  max-height: 140px;\n  overflow-y: auto;\n}\n\n/* ---- SUMMARY / SETTINGS forms ---- */\n\n.zlc-field {\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n}\n.zlc-field > label {\n  font-size: 11px;\n  font-weight: 700;\n  color: var(--muted);\n}\n.zlc-field input[type="text"],\n.zlc-field input[type="password"],\n.zlc-field input[type="number"],\n.zlc-field select,\n.zlc-field textarea {\n  padding: 5px 7px;\n  border: 1px solid var(--border);\n  border-radius: 6px;\n  background: var(--bg-2);\n  color: var(--text);\n  font-family: inherit;\n  font-size: 12px;\n}\n.zlc-field textarea {\n  resize: vertical;\n  line-height: 1.5;\n}\n.zlc-field input:focus,\n.zlc-field select:focus,\n.zlc-field textarea:focus {\n  outline: 1px solid var(--accent-2);\n}\n\n.zlc-check {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 12px;\n  cursor: pointer;\n}\n.zlc-check input {\n  accent-color: var(--accent);\n}\n\n.zlc-row {\n  display: flex;\n  gap: 8px;\n  align-items: flex-end;\n}\n.zlc-row > .zlc-field {\n  flex: 1 1 0;\n}\n\n.zlc-note {\n  color: var(--muted);\n  font-size: 10.5px;\n}\n\n.zlc-confirm {\n  padding: 9px 10px;\n  border: 1px solid var(--warn);\n  border-radius: 7px;\n  background: rgba(255, 207, 107, 0.07);\n  font-size: 12px;\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.zlc-confirm .dest {\n  word-break: break-all;\n  font-weight: 700;\n}\n\n.zlc-result-meta {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  color: var(--muted);\n  font-size: 11.5px;\n}\n\n.zlc-status-line {\n  font-size: 11.5px;\n  min-height: 1.2em;\n  word-break: break-word;\n}\n.zlc-status-line.ok {\n  color: var(--ok);\n}\n.zlc-status-line.error {\n  color: var(--danger);\n}\n.zlc-status-line.busy {\n  color: var(--warn);\n}\n\n.zlc-hr {\n  border: none;\n  border-top: 1px solid var(--border);\n  margin: 4px 0;\n}\n\n.zlc-section-title {\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  color: var(--accent);\n  margin-top: 4px;\n}\n\n/* ---- collapsed ---- */\n\n.zlc-root.collapsed .zlc-header,\n.zlc-root.collapsed .zlc-tabs,\n.zlc-root.collapsed .zlc-panel,\n.zlc-root.collapsed .zlc-global-status,\n.zlc-root.collapsed .zlc-resize-handle {\n  display: none;\n}\n\n.zlc-expand-strip {\n  display: none;\n}\n.zlc-root.collapsed .zlc-expand-strip {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n  gap: 10px;\n  height: 100%;\n}\n.zlc-expand-strip .vertical-label {\n  writing-mode: vertical-rl;\n  color: var(--muted);\n  font-size: 10px;\n  letter-spacing: 0.15em;\n  user-select: none;\n}\n';

  // src/shared/messages.ts
  function sendToBackground(request) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(request, (response) => {
          const err = chrome.runtime.lastError;
          if (err || !response) {
            resolve({
              ok: false,
              error: err?.message ?? "background service worker \u304B\u3089\u5FDC\u7B54\u304C\u3042\u308A\u307E\u305B\u3093",
              code: "INTERNAL"
            });
            return;
          }
          resolve(response);
        });
      } catch (e) {
        resolve({
          ok: false,
          error: e instanceof Error ? e.message : String(e),
          code: "INTERNAL"
        });
      }
    });
  }

  // src/shared/types.ts
  var DEFAULT_SUMMARY_INSTRUCTION = `\u3042\u306A\u305F\u306F\u7269\u8A9E\u306E\u30B3\u30F3\u30C6\u30AD\u30B9\u30C8\u3092\u5727\u7E2E\u3059\u308B\u7DE8\u96C6\u8005\u3067\u3059\u3002

\u4E0E\u3048\u3089\u308C\u305F\u4F1A\u8A71\u30ED\u30B0\u3092\u3001\u6307\u5B9A\u3055\u308C\u305F\u6587\u5B57\u6570\u3092\u76EE\u5B89\u306B\u65E5\u672C\u8A9E\u3067\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002

\u5FC5\u305A\u4FDD\u6301\u3057\u3066\u304F\u3060\u3055\u3044\uFF1A

\u30FB\u767B\u5834\u4EBA\u7269
\u30FB\u4EBA\u7269\u306E\u6027\u683C
\u30FB\u4EBA\u7269\u540C\u58EB\u306E\u95A2\u4FC2
\u30FB\u91CD\u8981\u306A\u51FA\u6765\u4E8B
\u30FB\u611F\u60C5\u3084\u95A2\u4FC2\u6027\u306E\u5909\u5316
\u30FB\u73FE\u5728\u306E\u72B6\u6CC1
\u30FB\u5834\u6240\u3068\u6642\u9593
\u30FB\u672A\u89E3\u6C7A\u306E\u554F\u984C
\u30FB\u4ECA\u5F8C\u306E\u5C55\u958B\u306B\u5FC5\u8981\u306A\u4F0F\u7DDA
\u30FB\u4EBA\u7269\u304C\u660E\u78BA\u306B\u767A\u8A00\u3057\u305F\u91CD\u8981\u306A\u4E8B\u5B9F

\u65B0\u3057\u3044\u8A2D\u5B9A\u3084\u51FA\u6765\u4E8B\u3092\u8FFD\u52A0\u3057\u3066\u306F\u3044\u3051\u307E\u305B\u3093\u3002

\u6587\u7AE0\u3068\u3057\u3066\u81EA\u7136\u306B\u307E\u3068\u3081\u3066\u304F\u3060\u3055\u3044\u3002

\u76EE\u6A19\u6587\u5B57\u6570\uFF1A
{{targetChars}}\u6587\u5B57`;
  function defaultSettings() {
    return {
      autoSaveEnabled: true,
      autoSaveDebounceMs: 2e3,
      defaultTargetChars: 2e3,
      panelWidth: 420,
      layoutMode: "overlay",
      format: {
        speakerLabels: true,
        narrationLabels: true
      },
      provider: "openai-compatible",
      openaiCompatible: {
        endpoint: "http://127.0.0.1:1234/v1/chat/completions",
        model: "",
        temperature: 0.2
      },
      genericJson: {
        url: "",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        requestTemplate: `{
  "model": "{{model}}",
  "prompt": "{{instruction}}\\n\\n{{text}}",
  "target_length": "{{targetChars}}"
}`,
        responsePath: "result.text"
      },
      summaryInstruction: DEFAULT_SUMMARY_INSTRUCTION,
      maxInputCharsPerRequest: 12e3,
      rememberApiKey: false,
      acknowledgedRemoteOrigins: []
    };
  }
  var PANEL_MIN_WIDTH = 320;
  var PANEL_MAX_WIDTH = 700;
  var OVERLAY_VIEWPORT_THRESHOLD = 960;

  // src/content/panel.ts
  var HOST_ID = "zeta-log-companion-host";
  var DOCK_STYLE_ID = "zeta-log-companion-dock-style";
  var TEMPLATE = `
<div class="zlc-root">
  <div class="zlc-resize-handle" data-el="resizeHandle" title="\u30C9\u30E9\u30C3\u30B0\u3067\u5E45\u3092\u5909\u66F4"></div>

  <div class="zlc-expand-strip">
    <button class="zlc-icon-btn" data-el="btnExpand" title="\u5C55\u958B">\u25C0</button>
    <div class="vertical-label">zeta-manager</div>
  </div>

  <header class="zlc-header">
    <div class="zlc-title">zeta-manager</div>
    <button class="zlc-icon-btn" data-el="btnCollapse" title="\u6298\u308A\u305F\u305F\u3080">\u25B6</button>
  </header>

  <div class="zlc-global-status" data-el="globalStatus" hidden></div>

  <nav class="zlc-tabs">
    <button data-tab="live" class="active">LIVE</button>
    <button data-tab="archives">ARCHIVES</button>
    <button data-tab="summary">SUMMARY</button>
    <button data-tab="settings">SETTINGS</button>
  </nav>

  <section class="zlc-panel" data-panel="live">
    <div class="zlc-plot-name" data-el="plotName">\u2014</div>
    <div class="zlc-live-stats">
      <span data-el="liveMessages">0 messages</span> \u30FB
      <span data-el="liveChars">0 characters</span>
    </div>
    <div class="zlc-save-row">
      <span class="zlc-badge" data-el="autoSaveBadge">\u25CF Auto Save</span>
      <span data-el="lastSaved">\u672A\u4FDD\u5B58</span>
    </div>
    <div class="zlc-sync-progress" data-el="syncProgress" hidden></div>
    <div class="zlc-btn-row">
      <button class="zlc-btn primary" data-el="btnFullSync">\u5168\u5C65\u6B74\u3092\u540C\u671F</button>
      <button class="zlc-btn" data-el="btnSaveNow">\u4ECA\u3059\u3050\u4FDD\u5B58</button>
      <button class="zlc-btn" data-el="btnCopyLive">\u30B3\u30D4\u30FC</button>
    </div>
    <div class="zlc-status-line" data-el="liveStatus"></div>
    <textarea class="zlc-textarea" data-el="liveText" readonly spellcheck="false"></textarea>
  </section>

  <section class="zlc-panel" data-panel="archives" hidden>
    <div data-el="archiveListView">
      <div class="zlc-btn-row" style="margin-bottom:8px">
        <button class="zlc-btn" data-el="btnReloadArchives">\u518D\u8AAD\u307F\u8FBC\u307F</button>
      </div>
      <div class="zlc-status-line" data-el="archivesStatus"></div>
      <div data-el="archivesList" style="display:flex;flex-direction:column;gap:8px"></div>
    </div>
    <div data-el="archiveDetailView" hidden style="display:flex;flex-direction:column;gap:8px;flex:1 1 auto;min-height:0">
      <div class="zlc-btn-row">
        <button class="zlc-btn" data-el="btnArchiveBack">\u2190 \u4E00\u89A7\u3078</button>
      </div>
      <div class="zlc-plot-name" data-el="archiveTitle"></div>
      <div class="zlc-detail-meta" data-el="archiveMeta"></div>
      <div class="zlc-btn-row">
        <button class="zlc-btn" data-el="btnArchiveCopy">\u30B3\u30D4\u30FC</button>
        <button class="zlc-btn" data-el="btnArchiveSummarize">\u8981\u7D04</button>
        <button class="zlc-btn danger" data-el="btnArchiveDelete">\u524A\u9664</button>
      </div>
      <div class="zlc-status-line" data-el="archiveDetailStatus"></div>
      <textarea class="zlc-textarea" data-el="archiveText" readonly spellcheck="false"></textarea>
      <div class="zlc-section-title" data-el="archiveSummariesTitle" hidden>\u4FDD\u5B58\u6E08\u307F\u8981\u7D04</div>
      <div data-el="archiveSummaries" style="display:flex;flex-direction:column;gap:6px"></div>
    </div>
  </section>

  <section class="zlc-panel" data-panel="summary" hidden>
    <div class="zlc-field">
      <label>Source</label>
      <select data-el="summarySource"></select>
    </div>
    <div class="zlc-row">
      <div class="zlc-field">
        <label>Target characters</label>
        <input type="number" data-el="summaryTarget" min="100" step="100" />
      </div>
    </div>
    <div class="zlc-field">
      <label>Provider</label>
      <div class="zlc-result-meta">
        <span data-el="summaryProviderName"></span>
        <span class="zlc-badge" data-el="summaryEndpointBadge"></span>
      </div>
      <div class="zlc-note" data-el="summaryProviderDetail"></div>
    </div>
    <div class="zlc-btn-row">
      <button class="zlc-btn primary" data-el="btnSummarize">\u8981\u7D04\u3059\u308B</button>
    </div>
    <div class="zlc-confirm" data-el="remoteConfirm" hidden>
      <div>\u3053\u306E\u4F1A\u8A71\u30ED\u30B0\u306F\u8A2D\u5B9A\u3055\u308C\u305F\u5916\u90E8LLM\u30B5\u30FC\u30D3\u30B9\u3078\u9001\u4FE1\u3055\u308C\u307E\u3059\u3002</div>
      <div>\u9001\u4FE1\u5148: <span class="dest" data-el="remoteConfirmDest"></span></div>
      <div>\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F</div>
      <div class="zlc-btn-row">
        <button class="zlc-btn primary" data-el="btnRemoteProceed">\u7D9A\u884C\u3059\u308B</button>
        <button class="zlc-btn" data-el="btnRemoteCancel">\u30AD\u30E3\u30F3\u30BB\u30EB</button>
      </div>
    </div>
    <div class="zlc-btn-row" data-el="permissionActions" hidden>
      <button class="zlc-btn" data-el="btnOpenOptionsFromSummary">\u6A29\u9650\u8A2D\u5B9A\u30DA\u30FC\u30B8\u3092\u958B\u304F</button>
    </div>
    <div class="zlc-status-line" data-el="summaryStatus"></div>
    <div data-el="summaryResultBlock" hidden style="display:flex;flex-direction:column;gap:8px;flex:1 1 auto;min-height:0">
      <hr class="zlc-hr" />
      <div class="zlc-result-meta">
        <span>Result</span>
        <span data-el="summaryResultChars"></span>
      </div>
      <div class="zlc-btn-row">
        <button class="zlc-btn" data-el="btnCopySummary">\u30B3\u30D4\u30FC</button>
        <button class="zlc-btn" data-el="btnSaveSummary">\u4FDD\u5B58</button>
        <button class="zlc-btn" data-el="btnRegenerate">\u518D\u751F\u6210</button>
      </div>
      <textarea class="zlc-textarea" data-el="summaryText" readonly spellcheck="false"></textarea>
    </div>
  </section>

  <section class="zlc-panel" data-panel="settings" hidden>
    <label class="zlc-check">
      <input type="checkbox" data-el="setAutoSave" /> Auto Save \u3092\u6709\u52B9\u306B\u3059\u308B
    </label>
    <div class="zlc-row">
      <div class="zlc-field">
        <label>Auto Save Debounce (ms)</label>
        <input type="number" data-el="setDebounce" min="500" step="100" />
      </div>
      <div class="zlc-field">
        <label>Default summary length</label>
        <input type="number" data-el="setTargetChars" min="100" step="100" />
      </div>
    </div>
    <div class="zlc-row">
      <div class="zlc-field">
        <label>Panel width (px)</label>
        <input type="number" data-el="setPanelWidth" min="320" max="700" step="10" />
      </div>
      <div class="zlc-field">
        <label>\u5206\u5272\u8981\u7D04\u306E\u6700\u5927\u5165\u529B\u6587\u5B57\u6570</label>
        <input type="number" data-el="setMaxInput" min="2000" step="1000" />
      </div>
    </div>
    <div class="zlc-field">
      <label>\u8868\u793A\u30E2\u30FC\u30C9</label>
      <select data-el="setLayoutMode">
        <option value="overlay">Overlay\uFF08\u65E2\u5B9A\u30FBZeta\u306E\u30EC\u30A4\u30A2\u30A6\u30C8\u306B\u5F71\u97FF\u3057\u306A\u3044\uFF09</option>
        <option value="dock">Dock\uFF08\u5B9F\u9A13\u7684\u30FB#contents \u3092\u30DA\u30A4\u30F3\u5E45\u3076\u3093\u7E2E\u3081\u308B\uFF09</option>
      </select>
      <div class="zlc-note">Dock \u3067\u8868\u793A\u304C\u5D29\u308C\u308B\u5834\u5408\u306F Overlay \u306B\u623B\u3057\u3066\u30DA\u30FC\u30B8\u3092\u518D\u8AAD\u307F\u8FBC\u307F\u3057\u3066\u304F\u3060\u3055\u3044</div>
    </div>
    <label class="zlc-check">
      <input type="checkbox" data-el="setSpeakerLabels" /> \u8A71\u8005\u30E9\u30D9\u30EB\u3092\u4ED8\u3051\u308B
    </label>
    <label class="zlc-check">
      <input type="checkbox" data-el="setNarrationLabels" /> \u30CA\u30EC\u30FC\u30B7\u30E7\u30F3\u30E9\u30D9\u30EB\u3092\u4ED8\u3051\u308B
    </label>

    <hr class="zlc-hr" />
    <div class="zlc-section-title">LLM PROVIDER</div>
    <div class="zlc-field">
      <label>Provider</label>
      <select data-el="setProvider">
        <option value="openai-compatible">OpenAI Compatible (LM Studio / llama.cpp \u7B49)</option>
        <option value="generic-json">Generic JSON HTTP</option>
      </select>
    </div>

    <div data-el="openaiFields" style="display:flex;flex-direction:column;gap:10px">
      <div class="zlc-field">
        <label>Endpoint</label>
        <input type="text" data-el="setOaiEndpoint" placeholder="http://127.0.0.1:1234/v1/chat/completions" spellcheck="false" />
      </div>
      <div class="zlc-row">
        <div class="zlc-field">
          <label>Model</label>
          <input type="text" data-el="setOaiModel" spellcheck="false" />
        </div>
        <div class="zlc-field">
          <label>Temperature</label>
          <input type="number" data-el="setOaiTemperature" min="0" max="2" step="0.1" />
        </div>
      </div>
    </div>

    <div data-el="genericFields" hidden style="display:flex;flex-direction:column;gap:10px">
      <div class="zlc-field">
        <label>URL</label>
        <input type="text" data-el="setGjUrl" spellcheck="false" />
      </div>
      <div class="zlc-field">
        <label>HTTP Method</label>
        <select data-el="setGjMethod">
          <option value="POST">POST</option>
          <option value="PUT">PUT</option>
          <option value="GET">GET</option>
        </select>
      </div>
      <div class="zlc-field">
        <label>Headers (JSON)</label>
        <textarea data-el="setGjHeaders" rows="3" spellcheck="false"></textarea>
        <div class="zlc-note">\u5024\u306B\u306F {{apiKey}} \u3092\u4F7F\u7528\u3067\u304D\u307E\u3059</div>
      </div>
      <div class="zlc-field">
        <label>JSON Request Template</label>
        <textarea data-el="setGjTemplate" rows="6" spellcheck="false"></textarea>
        <div class="zlc-note">{{text}} {{targetChars}} {{instruction}} {{model}} {{apiKey}} \u3092\u7F6E\u63DB\u3057\u307E\u3059</div>
      </div>
      <div class="zlc-field">
        <label>Response JSON Path</label>
        <input type="text" data-el="setGjPath" placeholder="result.text" spellcheck="false" />
      </div>
    </div>

    <div class="zlc-field">
      <label>API Key</label>
      <input type="password" data-el="setApiKey" autocomplete="off" spellcheck="false" />
      <div class="zlc-note" data-el="apiKeyHint"></div>
      <div class="zlc-btn-row">
        <button class="zlc-btn danger" data-el="btnClearApiKey">API\u30AD\u30FC\u3092\u524A\u9664</button>
      </div>
    </div>
    <label class="zlc-check">
      <input type="checkbox" data-el="setRememberKey" /> API\u30AD\u30FC\u3092\u4FDD\u5B58\u3059\u308B\uFF08\u6C38\u7D9A\u5316\uFF09
    </label>
    <div class="zlc-note">\u30AA\u30D5\u306E\u5834\u5408\u3001API\u30AD\u30FC\u306F\u30D6\u30E9\u30A6\u30B6\u7D42\u4E86\u6642\u306B\u7834\u68C4\u3055\u308C\u307E\u3059 (session storage)</div>

    <hr class="zlc-hr" />
    <div class="zlc-field">
      <label>Summary instruction</label>
      <textarea data-el="setInstruction" rows="10" spellcheck="false"></textarea>
      <div class="zlc-note">{{targetChars}} \u304C\u76EE\u6A19\u6587\u5B57\u6570\u3078\u7F6E\u63DB\u3055\u308C\u307E\u3059</div>
    </div>

    <div class="zlc-btn-row">
      <button class="zlc-btn primary" data-el="btnSaveSettings">\u4FDD\u5B58</button>
      <button class="zlc-btn" data-el="btnTestLlm">\u63A5\u7D9A\u30C6\u30B9\u30C8</button>
      <button class="zlc-btn" data-el="btnOpenOptions">\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u6A29\u9650\u306E\u8A2D\u5B9A</button>
    </div>
    <div class="zlc-status-line" data-el="settingsStatus"></div>
  </section>
</div>
`;
  var ZlcPanel = class {
    constructor(hostApi) {
      this.hostApi = hostApi;
    }
    hostEl;
    shadow;
    rootEl;
    els = /* @__PURE__ */ new Map();
    settings;
    hasApiKey = false;
    width = 420;
    collapsed = false;
    overlayMode = false;
    summarySource = { kind: "live" };
    lastSummary = null;
    summarizing = false;
    pendingRemoteRun = null;
    resizeListener = () => this.applyLayout();
    /* ------------------------------------------------------------------ */
    /* mount / layout                                                      */
    mount(initial) {
      if (document.getElementById(HOST_ID)) return;
      this.settings = initial.settings;
      this.hasApiKey = initial.hasApiKey;
      this.width = clampWidth(initial.settings.panelWidth);
      this.hostEl = document.createElement("div");
      this.hostEl.id = HOST_ID;
      const s = this.hostEl.style;
      s.setProperty("position", "fixed", "important");
      s.setProperty("top", "0", "important");
      s.setProperty("right", "0", "important");
      s.setProperty("height", "100vh", "important");
      s.setProperty("z-index", "2147483646", "important");
      s.setProperty("margin", "0", "important");
      s.setProperty("padding", "0", "important");
      s.setProperty("border", "none", "important");
      s.setProperty("background", "transparent", "important");
      this.shadow = this.hostEl.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = panel_default;
      this.shadow.appendChild(style);
      const wrapper = document.createElement("div");
      wrapper.innerHTML = TEMPLATE;
      this.rootEl = wrapper.querySelector(".zlc-root");
      this.shadow.appendChild(this.rootEl);
      this.rootEl.querySelectorAll("[data-el]").forEach((el) => {
        this.els.set(el.dataset.el, el);
      });
      this.bindEvents();
      this.populateSettingsForm();
      this.refreshSummaryProviderInfo();
      this.updateAutoSaveBadge();
      this.el("summaryTarget").value = String(
        this.settings.defaultTargetChars
      );
      this.rebuildSummarySourceSelect();
      (document.body ?? document.documentElement).appendChild(this.hostEl);
      window.addEventListener("resize", this.resizeListener);
      this.applyLayout();
    }
    unmount() {
      window.removeEventListener("resize", this.resizeListener);
      document.getElementById(DOCK_STYLE_ID)?.remove();
      this.hostEl?.remove();
    }
    /** Room ページ以外ではペインを隠す。 */
    setVisible(visible) {
      if (!this.hostEl) return;
      this.hostEl.style.setProperty("display", visible ? "block" : "none", "important");
      if (visible) {
        this.applyLayout();
      } else {
        document.getElementById(DOCK_STYLE_ID)?.remove();
      }
    }
    el(name) {
      const el = this.els.get(name);
      if (!el) throw new Error(`panel element not found: ${name}`);
      return el;
    }
    input(name) {
      return this.el(name);
    }
    textarea(name) {
      return this.el(name);
    }
    select(name) {
      return this.el(name);
    }
    applyLayout() {
      this.overlayMode = window.innerWidth < OVERLAY_VIEWPORT_THRESHOLD;
      const effectiveWidth = this.collapsed ? 34 : this.width;
      this.hostEl.style.setProperty("width", `${effectiveWidth}px`, "important");
      this.rootEl.classList.toggle("collapsed", this.collapsed);
      let dockStyle = document.getElementById(DOCK_STYLE_ID);
      const contents = document.querySelector("#contents");
      const shouldDock = this.settings.layoutMode === "dock" && !this.overlayMode && contents !== null && contents.querySelector('[role="log"]') !== null;
      if (shouldDock) {
        if (!dockStyle) {
          dockStyle = document.createElement("style");
          dockStyle.id = DOCK_STYLE_ID;
          document.head.appendChild(dockStyle);
        }
        const css = `#contents { margin-right: ${effectiveWidth}px !important; }`;
        if (dockStyle.textContent !== css) dockStyle.textContent = css;
      } else if (dockStyle) {
        dockStyle.remove();
      }
    }
    bindResize() {
      const handle = this.el("resizeHandle");
      let dragging = false;
      handle.addEventListener("pointerdown", (ev) => {
        dragging = true;
        handle.setPointerCapture(ev.pointerId);
        ev.preventDefault();
      });
      handle.addEventListener("pointermove", (ev) => {
        if (!dragging) return;
        this.width = clampWidth(window.innerWidth - ev.clientX);
        this.applyLayout();
      });
      const stop = () => {
        if (!dragging) return;
        dragging = false;
        this.settings.panelWidth = this.width;
        this.el("setPanelWidth").value = String(this.width);
        void sendToBackground({
          type: "SAVE_SETTINGS",
          settings: this.settings
        });
      };
      handle.addEventListener("pointerup", stop);
      handle.addEventListener("pointercancel", stop);
    }
    /* ------------------------------------------------------------------ */
    /* events                                                              */
    bindEvents() {
      this.bindResize();
      this.el("btnCollapse").addEventListener("click", () => {
        this.collapsed = true;
        this.applyLayout();
      });
      this.el("btnExpand").addEventListener("click", () => {
        this.collapsed = false;
        this.applyLayout();
      });
      this.rootEl.querySelectorAll(".zlc-tabs button").forEach(
        (btn) => {
          btn.addEventListener("click", () => this.switchTab(btn.dataset.tab ?? "live"));
        }
      );
      this.el("btnFullSync").addEventListener("click", () => {
        this.hostApi.requestFullSync();
      });
      this.el("btnSaveNow").addEventListener("click", () => {
        this.hostApi.requestSaveNow();
      });
      this.el("btnCopyLive").addEventListener("click", async () => {
        const ok = await copyToClipboard(this.textarea("liveText").value);
        this.setStatus("liveStatus", ok ? "\u30B3\u30D4\u30FC\u3057\u307E\u3057\u305F" : "\u30B3\u30D4\u30FC\u306B\u5931\u6557\u3057\u307E\u3057\u305F", ok ? "ok" : "error");
      });
      this.el("btnReloadArchives").addEventListener("click", () => {
        void this.refreshArchives();
      });
      this.el("btnArchiveBack").addEventListener("click", () => {
        this.el("archiveDetailView").hidden = true;
        this.el("archiveListView").hidden = false;
        void this.refreshArchives();
      });
      this.el("btnArchiveCopy").addEventListener("click", async () => {
        const ok = await copyToClipboard(this.textarea("archiveText").value);
        this.setStatus("archiveDetailStatus", ok ? "\u30B3\u30D4\u30FC\u3057\u307E\u3057\u305F" : "\u30B3\u30D4\u30FC\u306B\u5931\u6557\u3057\u307E\u3057\u305F", ok ? "ok" : "error");
      });
      this.el("btnArchiveDelete").addEventListener("click", () => {
        void this.deleteCurrentArchive();
      });
      this.el("btnArchiveSummarize").addEventListener("click", () => {
        if (!this.currentArchive) return;
        this.summarySource = {
          kind: "archive",
          snapshotId: this.currentArchive.snapshot.id,
          label: this.currentArchive.snapshot.displayName,
          text: this.currentArchive.text
        };
        this.rebuildSummarySourceSelect();
        this.switchTab("summary");
      });
      this.select("summarySource").addEventListener("change", () => {
        const v = this.select("summarySource").value;
        if (v === "live") this.summarySource = { kind: "live" };
      });
      this.el("btnSummarize").addEventListener("click", () => {
        void this.runSummarize(false);
      });
      this.el("btnRemoteProceed").addEventListener("click", () => {
        this.el("remoteConfirm").hidden = true;
        const run = this.pendingRemoteRun;
        this.pendingRemoteRun = null;
        run?.();
      });
      this.el("btnRemoteCancel").addEventListener("click", () => {
        this.el("remoteConfirm").hidden = true;
        this.pendingRemoteRun = null;
        this.setStatus("summaryStatus", "\u9001\u4FE1\u3092\u30AD\u30E3\u30F3\u30BB\u30EB\u3057\u307E\u3057\u305F", "");
      });
      this.el("btnOpenOptionsFromSummary").addEventListener("click", () => {
        void sendToBackground({ type: "OPEN_OPTIONS" });
      });
      this.el("btnCopySummary").addEventListener("click", async () => {
        const ok = await copyToClipboard(this.textarea("summaryText").value);
        this.setStatus("summaryStatus", ok ? "\u30B3\u30D4\u30FC\u3057\u307E\u3057\u305F" : "\u30B3\u30D4\u30FC\u306B\u5931\u6557\u3057\u307E\u3057\u305F", ok ? "ok" : "error");
      });
      this.el("btnSaveSummary").addEventListener("click", () => {
        void this.saveCurrentSummary();
      });
      this.el("btnRegenerate").addEventListener("click", () => {
        void this.runSummarize(false);
      });
      this.select("setProvider").addEventListener("change", () => {
        this.toggleProviderFields(this.select("setProvider").value);
      });
      this.el("btnSaveSettings").addEventListener("click", () => {
        void this.saveSettingsFromForm();
      });
      this.el("btnClearApiKey").addEventListener("click", () => {
        void this.clearApiKey();
      });
      this.el("btnTestLlm").addEventListener("click", () => {
        void this.testConnection();
      });
      this.el("btnOpenOptions").addEventListener("click", () => {
        void sendToBackground({ type: "OPEN_OPTIONS" });
      });
    }
    switchTab(tab) {
      this.rootEl.querySelectorAll(".zlc-tabs button").forEach(
        (btn) => btn.classList.toggle("active", btn.dataset.tab === tab)
      );
      this.rootEl.querySelectorAll("[data-panel]").forEach((panel) => panel.hidden = panel.dataset.panel !== tab);
      if (tab === "archives") void this.refreshArchives();
      if (tab === "summary") this.refreshSummaryProviderInfo();
    }
    /* ------------------------------------------------------------------ */
    /* LIVE                                                                */
    setPlotName(name) {
      this.el("plotName").textContent = name ?? "\u2014";
    }
    updateLive(messageCount, charCount, text) {
      this.el("liveMessages").textContent = `${messageCount} messages`;
      this.el("liveChars").textContent = `${charCount.toLocaleString("en-US")} characters`;
      const ta = this.textarea("liveText");
      if (this.shadow.activeElement !== ta) {
        const nearBottom = ta.scrollTop + ta.clientHeight >= ta.scrollHeight - 40;
        ta.value = text;
        if (nearBottom) ta.scrollTop = ta.scrollHeight;
      }
    }
    setLastSaved(result) {
      this.el("lastSaved").textContent = result ? `Last saved ${formatTimeLocal(result.savedAt)}` : "\u672A\u4FDD\u5B58";
    }
    updateAutoSaveBadge() {
      const badge = this.el("autoSaveBadge");
      const on = this.settings.autoSaveEnabled;
      badge.textContent = on ? "\u25CF Auto Save" : "\u25CB Auto Save OFF";
      badge.classList.toggle("on", on);
      badge.classList.toggle("off", !on);
    }
    setSyncProgress(message) {
      const box = this.el("syncProgress");
      const btn = this.el("btnFullSync");
      if (message === null) {
        box.hidden = true;
        btn.disabled = false;
      } else {
        box.hidden = false;
        box.textContent = message;
        btn.disabled = true;
      }
    }
    setLiveStatus(message, kind = "") {
      this.setStatus("liveStatus", message, kind);
    }
    /** §34 のエラー表示。 */
    showGlobalStatus(message, kind = "info") {
      const box = this.el("globalStatus");
      if (message === null) {
        box.hidden = true;
        return;
      }
      box.hidden = false;
      box.textContent = message;
      box.classList.remove("error", "info");
      box.classList.add(kind);
    }
    /* ------------------------------------------------------------------ */
    /* ARCHIVES                                                            */
    currentArchive = null;
    async refreshArchives() {
      this.setStatus("archivesStatus", "\u8AAD\u307F\u8FBC\u307F\u4E2D\u2026", "busy");
      const res = await sendToBackground({ type: "GET_ARCHIVES" });
      if (!res.ok) {
        this.setStatus("archivesStatus", `\u8AAD\u307F\u8FBC\u307F\u5931\u6557: ${res.error}`, "error");
        return;
      }
      this.setStatus("archivesStatus", "", "");
      this.renderArchiveList(res.data);
    }
    renderArchiveList(items) {
      const list = this.el("archivesList");
      list.textContent = "";
      if (items.length === 0) {
        const empty = document.createElement("div");
        empty.className = "zlc-empty";
        empty.textContent = "\u4FDD\u5B58\u3055\u308C\u305F\u30ED\u30B0\u306F\u307E\u3060\u3042\u308A\u307E\u305B\u3093";
        list.appendChild(empty);
        return;
      }
      for (const snap of items) {
        const item = document.createElement("div");
        item.className = "zlc-archive-item";
        const name = document.createElement("div");
        name.className = "name";
        name.textContent = snap.displayName;
        const meta = document.createElement("div");
        meta.className = "meta";
        meta.textContent = `${formatTimeLocal(snap.updatedAt)} \u30FB ${snap.messageCount} messages \u30FB ${snap.characterCount.toLocaleString("en-US")} chars`;
        item.appendChild(name);
        item.appendChild(meta);
        item.addEventListener("click", () => void this.openArchive(snap.id));
        list.appendChild(item);
      }
    }
    async openArchive(snapshotId) {
      this.setStatus("archivesStatus", "\u8AAD\u307F\u8FBC\u307F\u4E2D\u2026", "busy");
      const res = await sendToBackground({
        type: "GET_ARCHIVE",
        snapshotId
      });
      if (!res.ok) {
        this.setStatus("archivesStatus", `\u8AAD\u307F\u8FBC\u307F\u5931\u6557: ${res.error}`, "error");
        return;
      }
      this.setStatus("archivesStatus", "", "");
      this.currentArchive = res.data;
      this.el("archiveListView").hidden = true;
      this.el("archiveDetailView").hidden = false;
      this.el("archiveTitle").textContent = res.data.snapshot.displayName;
      this.el("archiveMeta").textContent = `${res.data.snapshot.messageCount} messages \u30FB ${res.data.snapshot.characterCount.toLocaleString("en-US")} chars \u30FB \u66F4\u65B0 ${formatTimeLocal(res.data.snapshot.updatedAt)}`;
      this.textarea("archiveText").value = res.data.text;
      this.textarea("archiveText").scrollTop = 0;
      this.setStatus("archiveDetailStatus", "", "");
      this.renderArchiveSummaries(res.data);
    }
    renderArchiveSummaries(detail) {
      const box = this.el("archiveSummaries");
      const title = this.el("archiveSummariesTitle");
      box.textContent = "";
      title.hidden = detail.summaries.length === 0;
      for (const summary of detail.summaries) {
        const item = document.createElement("div");
        item.className = "zlc-summary-item";
        const meta = document.createElement("div");
        meta.className = "meta";
        meta.textContent = `${formatTimeLocal(summary.createdAt)} \u30FB ${summary.actualChars} chars \u30FB ${summary.provider}`;
        const body = document.createElement("div");
        body.className = "body";
        body.textContent = summary.text;
        item.appendChild(meta);
        item.appendChild(body);
        box.appendChild(item);
      }
    }
    async deleteCurrentArchive() {
      if (!this.currentArchive) return;
      const name = this.currentArchive.snapshot.displayName;
      if (!window.confirm(`\u30A2\u30FC\u30AB\u30A4\u30D6\u300C${name}\u300D\u3092\u524A\u9664\u3057\u307E\u3059\u304B\uFF1F`)) return;
      const res = await sendToBackground({
        type: "DELETE_ARCHIVE",
        snapshotId: this.currentArchive.snapshot.id
      });
      if (!res.ok) {
        this.setStatus("archiveDetailStatus", `\u524A\u9664\u5931\u6557: ${res.error}`, "error");
        return;
      }
      this.currentArchive = null;
      this.el("archiveDetailView").hidden = true;
      this.el("archiveListView").hidden = false;
      void this.refreshArchives();
    }
    /* ------------------------------------------------------------------ */
    /* SUMMARY                                                             */
    rebuildSummarySourceSelect() {
      const select = this.select("summarySource");
      select.textContent = "";
      const live = document.createElement("option");
      live.value = "live";
      live.textContent = "Current conversation\uFF08\u73FE\u5728\u306E\u4F1A\u8A71\uFF09";
      select.appendChild(live);
      if (this.summarySource.kind === "archive") {
        const arc = document.createElement("option");
        arc.value = "archive";
        arc.textContent = `Archive: ${this.summarySource.label}`;
        select.appendChild(arc);
        select.value = "archive";
      } else {
        select.value = "live";
      }
    }
    refreshSummaryProviderInfo() {
      const providerName = this.settings.provider === "openai-compatible" ? "OpenAI Compatible" : "Generic JSON HTTP";
      const endpoint = this.settings.provider === "openai-compatible" ? this.settings.openaiCompatible.endpoint : this.settings.genericJson.url;
      const model = this.settings.provider === "openai-compatible" ? this.settings.openaiCompatible.model || "(model \u672A\u8A2D\u5B9A)" : "-";
      this.el("summaryProviderName").textContent = `${providerName} / ${model}`;
      const badge = this.el("summaryEndpointBadge");
      if (!endpoint) {
        badge.textContent = "\u672A\u8A2D\u5B9A";
        badge.classList.remove("local", "remote");
      } else if (isLocalEndpoint(endpoint)) {
        badge.textContent = "LOCAL";
        badge.classList.add("local");
        badge.classList.remove("remote");
      } else {
        badge.textContent = "REMOTE";
        badge.classList.add("remote");
        badge.classList.remove("local");
      }
      this.el("summaryProviderDetail").textContent = endpoint || "SETTINGS \u30BF\u30D6\u3067 Endpoint \u3092\u8A2D\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044";
    }
    setSummaryProgress(message) {
      if (this.summarizing) {
        this.setStatus("summaryStatus", message, "busy");
      }
    }
    resolveSummaryInput() {
      const selected = this.select("summarySource").value;
      if (selected === "archive" && this.summarySource.kind === "archive") {
        return {
          text: this.summarySource.text,
          sourceLabel: this.summarySource.label,
          roomId: this.summarySource.snapshotId.split(":")[0] ?? null,
          snapshotId: this.summarySource.snapshotId
        };
      }
      const ctx = this.hostApi.getRoomContext();
      const text = this.hostApi.getLiveText();
      if (!text) {
        this.setStatus("summaryStatus", "\u8981\u7D04\u5BFE\u8C61\u306E\u4F1A\u8A71\u304C\u3042\u308A\u307E\u305B\u3093", "error");
        return null;
      }
      return {
        text,
        sourceLabel: `${ctx.plotName ?? "\u73FE\u5728\u306E\u4F1A\u8A71"} (LIVE)`,
        roomId: ctx.roomId,
        snapshotId: null
      };
    }
    async runSummarize(confirmRemote) {
      if (this.summarizing) return;
      const input = this.resolveSummaryInput();
      if (!input) return;
      const targetChars = Math.max(
        100,
        Number.parseInt(this.input("summaryTarget").value, 10) || this.settings.defaultTargetChars
      );
      this.summarizing = true;
      this.el("btnSummarize").disabled = true;
      this.el("permissionActions").hidden = true;
      this.setStatus("summaryStatus", "\u8981\u7D04\u3092\u958B\u59CB\u3057\u307E\u3059\u2026", "busy");
      const res = await sendToBackground({
        type: "SUMMARIZE",
        text: input.text,
        targetChars,
        sourceLabel: input.sourceLabel,
        roomId: input.roomId,
        snapshotId: input.snapshotId,
        confirmRemote
      });
      this.summarizing = false;
      this.el("btnSummarize").disabled = false;
      if (!res.ok) {
        if (res.code === "NEEDS_REMOTE_CONFIRM") {
          this.el("remoteConfirmDest").textContent = res.origin ?? "(\u4E0D\u660E)";
          this.el("remoteConfirm").hidden = false;
          this.pendingRemoteRun = () => void this.runSummarize(true);
          this.setStatus("summaryStatus", "", "");
          return;
        }
        if (res.code === "NEEDS_HOST_PERMISSION") {
          this.el("permissionActions").hidden = false;
          this.setStatus("summaryStatus", res.error, "error");
          return;
        }
        this.setStatus("summaryStatus", `\u8981\u7D04\u306B\u5931\u6557\u3057\u307E\u3057\u305F: ${res.error}`, "error");
        return;
      }
      this.lastSummary = {
        result: res.data,
        sourceLabel: input.sourceLabel,
        roomId: input.roomId,
        snapshotId: input.snapshotId,
        targetChars
      };
      const parts = [];
      if (res.data.chunkCount > 1) parts.push(`${res.data.chunkCount} \u30C1\u30E3\u30F3\u30AF\u306B\u5206\u5272`);
      if (res.data.recompressCount > 0)
        parts.push(`\u518D\u5727\u7E2E ${res.data.recompressCount} \u56DE`);
      this.setStatus(
        "summaryStatus",
        parts.length > 0 ? `\u5B8C\u4E86\uFF08${parts.join(" / ")}\uFF09` : "\u5B8C\u4E86",
        "ok"
      );
      this.el("summaryResultBlock").hidden = false;
      this.el("summaryResultChars").textContent = `${res.data.chars.toLocaleString("en-US")} characters\uFF08\u76EE\u6A19 ${targetChars.toLocaleString("en-US")}\uFF09`;
      this.textarea("summaryText").value = res.data.text;
    }
    async saveCurrentSummary() {
      if (!this.lastSummary) return;
      const { result, sourceLabel, roomId, snapshotId, targetChars } = this.lastSummary;
      const input = {
        roomId,
        snapshotId,
        sourceLabel,
        provider: result.provider,
        model: result.model,
        targetChars,
        actualChars: result.chars,
        text: result.text
      };
      const res = await sendToBackground({ type: "SAVE_SUMMARY", summary: input });
      this.setStatus(
        "summaryStatus",
        res.ok ? "\u8981\u7D04\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F" : `\u4FDD\u5B58\u5931\u6557: ${res.error}`,
        res.ok ? "ok" : "error"
      );
    }
    /* ------------------------------------------------------------------ */
    /* SETTINGS                                                            */
    populateSettingsForm() {
      const st = this.settings;
      this.input("setAutoSave").checked = st.autoSaveEnabled;
      this.input("setDebounce").value = String(st.autoSaveDebounceMs);
      this.input("setTargetChars").value = String(st.defaultTargetChars);
      this.input("setPanelWidth").value = String(st.panelWidth);
      this.select("setLayoutMode").value = st.layoutMode;
      this.input("setMaxInput").value = String(st.maxInputCharsPerRequest);
      this.input("setSpeakerLabels").checked = st.format.speakerLabels;
      this.input("setNarrationLabels").checked = st.format.narrationLabels;
      this.select("setProvider").value = st.provider;
      this.toggleProviderFields(st.provider);
      this.input("setOaiEndpoint").value = st.openaiCompatible.endpoint;
      this.input("setOaiModel").value = st.openaiCompatible.model;
      this.input("setOaiTemperature").value = String(st.openaiCompatible.temperature);
      this.input("setGjUrl").value = st.genericJson.url;
      this.select("setGjMethod").value = st.genericJson.method;
      this.textarea("setGjHeaders").value = JSON.stringify(
        st.genericJson.headers,
        null,
        2
      );
      this.textarea("setGjTemplate").value = st.genericJson.requestTemplate;
      this.input("setGjPath").value = st.genericJson.responsePath;
      this.input("setApiKey").value = "";
      this.el("apiKeyHint").textContent = this.hasApiKey ? "API\u30AD\u30FC\u306F\u4FDD\u5B58\u6E08\u307F\u3067\u3059\u3002\u5909\u66F4\u3059\u308B\u5834\u5408\u306E\u307F\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002" : "\u672A\u8A2D\u5B9A\u3067\u3059\u3002";
      this.input("setRememberKey").checked = st.rememberApiKey;
      this.textarea("setInstruction").value = st.summaryInstruction;
    }
    toggleProviderFields(provider) {
      this.el("openaiFields").hidden = provider !== "openai-compatible";
      this.el("genericFields").hidden = provider !== "generic-json";
    }
    collectSettingsForm() {
      const readInt = (name, min, fallback) => {
        const v = Number.parseInt(this.input(name).value, 10);
        return Number.isFinite(v) ? Math.max(min, v) : fallback;
      };
      let headers;
      const headersRaw = this.textarea("setGjHeaders").value.trim();
      if (headersRaw === "") {
        headers = {};
      } else {
        try {
          const parsed = JSON.parse(headersRaw);
          if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
            return "Headers \u306F JSON \u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u3067\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044";
          }
          headers = {};
          for (const [k, v] of Object.entries(parsed)) headers[k] = String(v);
        } catch {
          return "Headers \u306E JSON \u304C\u4E0D\u6B63\u3067\u3059";
        }
      }
      const provider = this.select("setProvider").value;
      const template = this.textarea("setGjTemplate").value;
      if (provider === "generic-json") {
        try {
          JSON.parse(template);
        } catch {
          return "JSON Request Template \u304C JSON \u3068\u3057\u3066\u4E0D\u6B63\u3067\u3059";
        }
      }
      const temperature = Number.parseFloat(this.input("setOaiTemperature").value);
      return {
        autoSaveEnabled: this.input("setAutoSave").checked,
        autoSaveDebounceMs: readInt("setDebounce", 500, 2e3),
        defaultTargetChars: readInt("setTargetChars", 100, 2e3),
        panelWidth: clampWidth(readInt("setPanelWidth", PANEL_MIN_WIDTH, 420)),
        layoutMode: this.select("setLayoutMode").value === "dock" ? "dock" : "overlay",
        format: {
          speakerLabels: this.input("setSpeakerLabels").checked,
          narrationLabels: this.input("setNarrationLabels").checked
        },
        provider,
        openaiCompatible: {
          endpoint: this.input("setOaiEndpoint").value.trim(),
          model: this.input("setOaiModel").value.trim(),
          temperature: Number.isFinite(temperature) ? temperature : 0.2
        },
        genericJson: {
          url: this.input("setGjUrl").value.trim(),
          method: this.select("setGjMethod").value,
          headers,
          requestTemplate: template,
          responsePath: this.input("setGjPath").value.trim()
        },
        summaryInstruction: this.textarea("setInstruction").value,
        maxInputCharsPerRequest: readInt("setMaxInput", 2e3, 12e3),
        rememberApiKey: this.input("setRememberKey").checked,
        acknowledgedRemoteOrigins: this.settings.acknowledgedRemoteOrigins
      };
    }
    async saveSettingsFromForm() {
      const collected = this.collectSettingsForm();
      if (typeof collected === "string") {
        this.setStatus("settingsStatus", collected, "error");
        return;
      }
      const apiKeyValue = this.input("setApiKey").value;
      const res = await sendToBackground({
        type: "SAVE_SETTINGS",
        settings: collected,
        // 空欄は「変更なし」。削除は btnClearApiKey で明示的に行う。
        apiKey: apiKeyValue !== "" ? apiKeyValue : void 0
      });
      if (!res.ok) {
        this.setStatus("settingsStatus", `\u4FDD\u5B58\u5931\u6557: ${res.error}`, "error");
        return;
      }
      this.settings = res.data.settings;
      this.hasApiKey = res.data.hasApiKey;
      this.width = clampWidth(this.settings.panelWidth);
      this.populateSettingsForm();
      this.refreshSummaryProviderInfo();
      this.updateAutoSaveBadge();
      this.applyLayout();
      this.hostApi.onSettingsApplied(this.settings);
      this.setStatus("settingsStatus", "\u4FDD\u5B58\u3057\u307E\u3057\u305F", "ok");
    }
    async clearApiKey() {
      const res = await sendToBackground({
        type: "SAVE_SETTINGS",
        settings: this.settings,
        apiKey: ""
      });
      if (res.ok) {
        this.hasApiKey = res.data.hasApiKey;
        this.input("setApiKey").value = "";
        this.el("apiKeyHint").textContent = "\u672A\u8A2D\u5B9A\u3067\u3059\u3002";
        this.setStatus("settingsStatus", "API\u30AD\u30FC\u3092\u524A\u9664\u3057\u307E\u3057\u305F", "ok");
      } else {
        this.setStatus("settingsStatus", `\u524A\u9664\u5931\u6557: ${res.error}`, "error");
      }
    }
    async testConnection() {
      this.setStatus("settingsStatus", "\u63A5\u7D9A\u30C6\u30B9\u30C8\u4E2D\u2026\uFF08\u672A\u4FDD\u5B58\u306E\u5909\u66F4\u306F\u53CD\u6620\u3055\u308C\u307E\u305B\u3093\uFF09", "busy");
      const res = await sendToBackground({
        type: "TEST_LLM_CONNECTION"
      });
      if (!res.ok) {
        if (res.code === "NEEDS_HOST_PERMISSION") {
          this.setStatus(
            "settingsStatus",
            `${res.error}\u300C\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u6A29\u9650\u306E\u8A2D\u5B9A\u300D\u304B\u3089\u8A31\u53EF\u3057\u3066\u304F\u3060\u3055\u3044\u3002`,
            "error"
          );
        } else {
          this.setStatus("settingsStatus", res.error, "error");
        }
        return;
      }
      this.setStatus(
        "settingsStatus",
        `[${res.data.endpointKind}] ${res.data.detail}`,
        res.data.ok ? "ok" : "error"
      );
    }
    /* ------------------------------------------------------------------ */
    setStatus(name, message, kind) {
      const el = this.el(name);
      el.textContent = message;
      el.classList.remove("ok", "error", "busy");
      if (kind) el.classList.add(kind);
    }
  };
  function clampWidth(width) {
    if (!Number.isFinite(width)) return 420;
    return Math.min(PANEL_MAX_WIDTH, Math.max(PANEL_MIN_WIDTH, Math.round(width)));
  }
  async function copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand("copy");
        ta.remove();
        return ok;
      } catch {
        return false;
      }
    }
  }

  // src/shared/text-format.ts
  var MESSAGE_SEPARATOR = "\n\n---\n\n";
  var DEFAULT_FORMAT_OPTIONS = {
    speakerLabels: true,
    narrationLabels: true
  };
  function formatMessage(record, options = DEFAULT_FORMAT_OPTIONS) {
    const blocks = [];
    if (record.role === "user") {
      blocks.push(
        options.speakerLabels && record.speaker ? `[USER: ${record.speaker}]` : "[USER]"
      );
      for (const part of record.parts) {
        if (part.text) blocks.push(part.text);
      }
    } else {
      blocks.push(
        options.speakerLabels && record.speaker ? `[AI: ${record.speaker}]` : "[AI]"
      );
      for (const part of record.parts) {
        if (!part.text) continue;
        if (options.narrationLabels) {
          if (part.type === "narration") {
            blocks.push("[NARRATION]");
          } else {
            const speaker = options.speakerLabels ? part.speaker ?? record.speaker : null;
            blocks.push(speaker ? `[CHARACTER: ${speaker}]` : "[CHARACTER]");
          }
        }
        blocks.push(part.text);
      }
    }
    return blocks.join("\n\n");
  }
  function formatTranscript(records, options = DEFAULT_FORMAT_OPTIONS) {
    return formatMessageBlocks(records, options).join(MESSAGE_SEPARATOR);
  }
  function formatMessageBlocks(records, options = DEFAULT_FORMAT_OPTIONS) {
    return records.filter((r) => r.active).slice().sort((a, b) => a.index - b.index).map((r) => formatMessage(r, options)).filter((block) => block.length > 0);
  }

  // src/content/content.ts
  var ROUTE_POLL_MS = 1e3;
  var CONTAINER_POLL_MS = 500;
  var CONTAINER_POLL_LIMIT = 40;
  var App = class {
    settings = defaultSettings();
    panel;
    store = new ConversationStore();
    currentRoomId = null;
    plotName = null;
    liveText = "";
    passiveCapture = null;
    scrollTracker = new CaptureScrollTracker();
    lastCaptureSignature = "";
    containerPollTimer = null;
    containerPollCount = 0;
    fullSyncRunning = false;
    scheduleLiveUpdate = batchLiveUpdates(() => this.updatePanelLive());
    scheduleSave = debounce(() => void this.persist(false), 2e3);
    async start() {
      const res = await sendToBackground({ type: "GET_SETTINGS" });
      const initial = res.ok ? res.data : { settings: defaultSettings(), hasApiKey: false };
      this.settings = initial.settings;
      this.scheduleSave = debounce(
        () => void this.persist(false),
        this.settings.autoSaveDebounceMs
      );
      this.panel = new ZlcPanel({
        getLiveText: () => this.liveText,
        getRoomContext: () => ({
          roomId: this.currentRoomId,
          plotName: this.plotName
        }),
        requestFullSync: () => void this.runFullSyncFlow(),
        requestSaveNow: () => void this.persist(true),
        onSettingsApplied: (settings) => this.applySettings(settings)
      });
      this.panel.mount(initial);
      chrome.runtime.onMessage.addListener((message) => {
        if (message && message.type === "SUMMARY_PROGRESS") {
          this.panel.setSummaryProgress(message.message);
        }
      });
      window.setInterval(() => this.handleRouteChange(), ROUTE_POLL_MS);
      window.addEventListener("popstate", () => this.handleRouteChange());
      const flush = () => {
        if (this.store.hasDirty()) this.scheduleSave.flush();
      };
      document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "hidden") flush();
      });
      window.addEventListener("pagehide", flush);
      this.handleRouteChange();
    }
    applySettings(settings) {
      this.settings = settings;
      this.scheduleSave.cancel();
      this.scheduleSave = debounce(
        () => void this.persist(false),
        settings.autoSaveDebounceMs
      );
      this.updatePanelLive();
    }
    /* ------------------------------------------------------------------ */
    /* Room lifecycle (§13)                                                */
    handleRouteChange() {
      const roomId = getRoomId(location.pathname);
      if (roomId === this.currentRoomId) return;
      this.teardownRoom();
      this.currentRoomId = roomId;
      if (roomId) {
        this.panel.setVisible(true);
        this.panel.showGlobalStatus(null);
        this.initRoom();
      } else {
        this.panel.setVisible(false);
      }
    }
    teardownRoom() {
      this.passiveCapture?.stop();
      this.passiveCapture = null;
      this.scrollTracker.reset();
      this.lastCaptureSignature = "";
      this.scheduleLiveUpdate.cancel();
      if (this.containerPollTimer !== null) {
        window.clearTimeout(this.containerPollTimer);
        this.containerPollTimer = null;
      }
      this.containerPollCount = 0;
      if (this.currentRoomId && this.store.hasDirty()) {
        this.scheduleSave.flush();
      }
      this.scheduleSave.cancel();
      this.store.clear();
      this.plotName = null;
      this.liveText = "";
      if (this.panel) {
        this.panel.setPlotName(null);
        this.panel.updateLive(0, 0, "");
        this.panel.setLastSaved(null);
        this.panel.setSyncProgress(null);
      }
    }
    initRoom() {
      this.containerPollCount = 0;
      const poll = () => {
        this.containerPollTimer = null;
        if (!this.currentRoomId) return;
        const container = findLogContainer();
        if (container) {
          void this.attachToRoom(container);
          return;
        }
        this.containerPollCount++;
        if (this.containerPollCount >= CONTAINER_POLL_LIMIT) {
          this.panel.showGlobalStatus("Zeta conversation not detected", "error");
          return;
        }
        this.containerPollTimer = window.setTimeout(poll, CONTAINER_POLL_MS);
      };
      poll();
    }
    async attachToRoom(container) {
      const roomId = this.currentRoomId;
      if (!roomId) return;
      const seeded = await sendToBackground({
        type: "GET_ROOM_MESSAGES",
        roomId
      });
      if (this.currentRoomId !== roomId) return;
      if (seeded.ok && seeded.data.length > 0) {
        this.store.seed(seeded.data);
      }
      this.panel.showGlobalStatus(null);
      this.scanAndUpdate();
      if (this.store.hasDirty()) this.scheduleSave();
      this.passiveCapture = new PassiveCapture(container, () => {
        if (this.fullSyncRunning) return;
        this.scanAndUpdate();
        if (this.store.hasDirty()) this.scheduleSave();
      });
    }
    /* ------------------------------------------------------------------ */
    /* capture                                                             */
    /** 現在のウィンドウをストアへ接合する共通処理。時系列リストの件数を返す。 */
    captureAndMerge(roomId) {
      if (this.currentRoomId !== roomId) return this.store.activeCount;
      const name = getPlotName();
      if (name) this.plotName = name;
      const nodeCount = findMessageNodes().length;
      const { records, displaced } = captureVisibleWindow(roomId);
      if (nodeCount > 0 && records.length === 0 && displaced.length === 0) {
        this.panel.showGlobalStatus(
          "Zeta\u306E\u30DA\u30FC\u30B8\u69CB\u9020\u304C\u5909\u66F4\u3055\u308C\u305F\u53EF\u80FD\u6027\u304C\u3042\u308A\u307E\u3059\u3002",
          "error"
        );
      }
      if (records.length > 0 || displaced.length > 0) {
        const log = findLogContainer();
        const scroll = log ? findScrollContainer(log) : null;
        const atBottom = scroll ? isNearBottom(scroll) : false;
        const scrollDirection = scroll && !this.fullSyncRunning ? this.scrollTracker.observe(scroll, records.map((r) => r.messageKey)) : void 0;
        const signature = JSON.stringify([
          records.map((r) => [r.messageKey, r.contentHash]),
          displaced.map((r) => [r.messageKey, r.contentHash]),
          atBottom
        ]);
        if (signature === this.lastCaptureSignature) return this.store.activeCount;
        this.lastCaptureSignature = signature;
        this.store.mergeWindow(records, { atBottom, displaced, scrollDirection });
      }
      if (!this.fullSyncRunning) this.scheduleLiveUpdate();
      return this.store.activeCount;
    }
    /** Passive Capture。Full Sync 中は同期側の collect に任せて何もしない。 */
    scanAndUpdate() {
      const roomId = this.currentRoomId;
      if (!roomId) return 0;
      if (this.fullSyncRunning) return this.store.activeCount;
      return this.captureAndMerge(roomId);
    }
    updatePanelLive() {
      const active = this.store.getActiveSorted();
      const text = formatTranscript(active, this.settings.format);
      this.panel.setPlotName(this.plotName);
      if (text !== this.liveText) {
        this.liveText = text;
        this.panel.updateLive(active.length, countChars(text), text);
      }
    }
    /* ------------------------------------------------------------------ */
    /* save (§14)                                                          */
    async persist(force) {
      const roomId = this.currentRoomId;
      if (!roomId) return;
      if (!this.settings.autoSaveEnabled && !force) return;
      const room = {
        roomId,
        plotName: this.plotName ?? "",
        url: location.origin + location.pathname
      };
      const dirty = this.store.drainDirty();
      if (dirty.length > 0) {
        const res = await sendToBackground({
          type: "UPSERT_MESSAGES",
          room,
          records: dirty
        });
        if (!res.ok) {
          this.store.markDirty(dirty);
          this.panel.setLiveStatus(`\u4FDD\u5B58\u5931\u6557: ${res.error}`, "error");
          return;
        }
      }
      if (dirty.length > 0 || force) {
        const res = await sendToBackground({
          type: "SAVE_SNAPSHOT",
          room
        });
        if (res.ok) {
          this.panel.setLastSaved(res.data);
          if (force) this.panel.setLiveStatus("\u4FDD\u5B58\u3057\u307E\u3057\u305F", "ok");
        } else if (force) {
          this.panel.setLiveStatus(`\u4FDD\u5B58\u5931\u6557: ${res.error}`, "error");
        }
      }
    }
    /* ------------------------------------------------------------------ */
    /* Full Sync (§10)                                                     */
    async runFullSyncFlow() {
      if (this.fullSyncRunning) return;
      const roomAtStart = this.currentRoomId;
      if (!roomAtStart) return;
      const log = findLogContainer();
      if (!log) {
        this.panel.setLiveStatus("Zeta conversation not detected", "error");
        return;
      }
      this.fullSyncRunning = true;
      this.lastCaptureSignature = "";
      this.scheduleLiveUpdate.cancel();
      this.scrollTracker.reset();
      this.store.beginRebuild();
      this.panel.setSyncProgress("\u5C65\u6B74\u540C\u671F\u3092\u958B\u59CB\u2026");
      let result = null;
      try {
        result = await runFullSync({
          container: findScrollContainer(log),
          collect: () => this.captureAndMerge(roomAtStart),
          onProgress: (p) => {
            if (p.phase === "loading") {
              this.panel.setSyncProgress(`\u904E\u53BB\u30ED\u30B0\u3092\u8AAD\u307F\u8FBC\u307F\u4E2D\u2026 (${p.steps})`);
            } else if (p.phase === "scanning") {
              this.panel.setSyncProgress(
                `\u5C65\u6B74\u53D6\u5F97\u4E2D\u2026 ${p.collectedMessages} messages`
              );
            } else if (p.phase === "restoring") {
              this.panel.setSyncProgress("\u30B9\u30AF\u30ED\u30FC\u30EB\u4F4D\u7F6E\u3092\u5FA9\u5143\u4E2D\u2026");
            }
          },
          shouldAbort: () => this.currentRoomId !== roomAtStart
        });
      } finally {
        this.store.finishRebuild();
        this.fullSyncRunning = false;
        this.lastCaptureSignature = "";
        this.panel.setSyncProgress(null);
        this.updatePanelLive();
      }
      if (result === null) {
        this.panel.setLiveStatus("\u540C\u671F\u4E2D\u306B\u30A8\u30E9\u30FC\u304C\u767A\u751F\u3057\u307E\u3057\u305F", "error");
        return;
      }
      if (result.aborted) {
        this.panel.setLiveStatus("\u540C\u671F\u306F\u672A\u5B8C\u4E86\u3067\u3059\uFF08\u4E2D\u65AD\u30FB\u8D70\u67FB\u4E0A\u9650\u30FB\u53D6\u5F97\u30A8\u30E9\u30FC\uFF09\u3002\u53D6\u5F97\u6E08\u307F\u306E\u30ED\u30B0\u306F\u4FDD\u6301\u3057\u307E\u3057\u305F\u3002", "error");
      } else {
        this.panel.setLiveStatus(
          `\u540C\u671F\u5B8C\u4E86: ${result.collectedMessages} messages \u53D6\u5F97`,
          "ok"
        );
      }
      if (this.currentRoomId === roomAtStart) {
        await this.persist(true);
      }
    }
  };
  (() => {
    if (window.__zetaLogCompanionLoaded) return;
    if (document.getElementById(HOST_ID)) return;
    window.__zetaLogCompanionLoaded = true;
    const boot = () => {
      startLorebookImporter();
      startSpeakerShortcuts();
      const app = new App();
      void app.start();
    };
    if (document.readyState === "complete") {
      boot();
    } else {
      window.addEventListener("load", boot, { once: true });
    }
  })();
})();
