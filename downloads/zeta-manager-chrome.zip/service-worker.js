"use strict";
(() => {
  // src/storage/database.ts
  var DB_NAME = "zetaLogCompanion";
  var DB_VERSION = 2;
  var STORE_ROOMS = "rooms";
  var STORE_MESSAGES = "messages";
  var STORE_SNAPSHOTS = "snapshots";
  var STORE_SUMMARIES = "summaries";
  function openDatabase(name = DB_NAME) {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(name, DB_VERSION);
      req.onupgradeneeded = (event) => {
        const db = req.result;
        const upgradeTx = req.transaction;
        if (event.oldVersion > 0 && event.oldVersion < 2 && upgradeTx) {
          for (const storeName of Array.from(db.objectStoreNames)) {
            upgradeTx.objectStore(storeName).clear();
          }
        }
        if (!db.objectStoreNames.contains(STORE_ROOMS)) {
          db.createObjectStore(STORE_ROOMS, { keyPath: "roomId" });
        }
        if (!db.objectStoreNames.contains(STORE_MESSAGES)) {
          const messages = db.createObjectStore(STORE_MESSAGES, {
            keyPath: ["roomId", "messageKey"]
          });
          messages.createIndex("byRoom", "roomId", { unique: false });
          messages.createIndex("byRoomIndex", ["roomId", "index"], {
            unique: false
          });
        }
        if (!db.objectStoreNames.contains(STORE_SNAPSHOTS)) {
          const snapshots = db.createObjectStore(STORE_SNAPSHOTS, {
            keyPath: "id"
          });
          snapshots.createIndex("byRoom", "roomId", { unique: false });
          snapshots.createIndex("byUpdatedAt", "updatedAt", { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_SUMMARIES)) {
          const summaries = db.createObjectStore(STORE_SUMMARIES, {
            keyPath: "id"
          });
          summaries.createIndex("byRoom", "roomId", { unique: false });
          summaries.createIndex("bySnapshot", "snapshotId", { unique: false });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error ?? new Error("IndexedDB open failed"));
    });
  }
  function requestToPromise(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error ?? new Error("IndexedDB request failed"));
    });
  }
  function transactionDone(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onabort = () => reject(tx.error ?? new Error("IndexedDB transaction aborted"));
      tx.onerror = () => reject(tx.error ?? new Error("IndexedDB transaction failed"));
    });
  }

  // src/shared/text-format.ts
  var MESSAGE_SEPARATOR = "\n\n---\n\n";
  var DEFAULT_FORMAT_OPTIONS = {
    speakerLabels: true,
    narrationLabels: true
  };
  function formatMessage(record, options = DEFAULT_FORMAT_OPTIONS) {
    const blocks = [];
    if (record.role === "user") {
      blocks.push(
        options.speakerLabels && record.speaker ? `[USER: ${record.speaker}]` : "[USER]"
      );
      for (const part of record.parts) {
        if (part.text) blocks.push(part.text);
      }
    } else {
      blocks.push(
        options.speakerLabels && record.speaker ? `[AI: ${record.speaker}]` : "[AI]"
      );
      for (const part of record.parts) {
        if (!part.text) continue;
        if (options.narrationLabels) {
          if (part.type === "narration") {
            blocks.push("[NARRATION]");
          } else {
            const speaker = options.speakerLabels ? part.speaker ?? record.speaker : null;
            blocks.push(speaker ? `[CHARACTER: ${speaker}]` : "[CHARACTER]");
          }
        }
        blocks.push(part.text);
      }
    }
    return blocks.join("\n\n");
  }
  function formatTranscript(records, options = DEFAULT_FORMAT_OPTIONS) {
    return formatMessageBlocks(records, options).join(MESSAGE_SEPARATOR);
  }
  function formatMessageBlocks(records, options = DEFAULT_FORMAT_OPTIONS) {
    return records.filter((r) => r.active).slice().sort((a, b) => a.index - b.index).map((r) => formatMessage(r, options)).filter((block) => block.length > 0);
  }

  // src/shared/utils.ts
  function countChars(text) {
    let n = 0;
    for (const _ of text) n++;
    return n;
  }
  function formatDateLocal(timestamp) {
    const d = new Date(timestamp);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  function truncate(text, max) {
    if (text.length <= max) return text;
    return text.slice(0, max) + "\u2026";
  }
  function isLocalEndpoint(url) {
    try {
      const u = new URL(url);
      return u.hostname === "localhost" || u.hostname === "127.0.0.1" || u.hostname === "[::1]" || u.hostname === "::1";
    } catch {
      return false;
    }
  }
  function originOf(url) {
    try {
      return new URL(url).origin;
    } catch {
      return null;
    }
  }
  function originPatternOf(url) {
    try {
      const u = new URL(url);
      if (u.protocol !== "http:" && u.protocol !== "https:") return null;
      return `${u.protocol}//${u.hostname}/*`;
    } catch {
      return null;
    }
  }
  function getByPath(obj, path) {
    if (!path) return void 0;
    let cur = obj;
    for (const rawSeg of path.split(".")) {
      const seg = rawSeg.trim();
      if (seg === "") return void 0;
      if (cur === null || cur === void 0) return void 0;
      if (Array.isArray(cur)) {
        const i = Number.parseInt(seg, 10);
        if (!Number.isInteger(i)) return void 0;
        cur = cur[i];
      } else if (typeof cur === "object") {
        cur = cur[seg];
      } else {
        return void 0;
      }
    }
    return cur;
  }
  function substitutePlaceholders(template, values) {
    return template.replace(
      /\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g,
      (match, name) => Object.prototype.hasOwnProperty.call(values, name) ? values[name] : match
    );
  }
  function randomId() {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
      return crypto.randomUUID();
    }
    return `id-${Date.now()}-${Math.floor(Math.random() * 1e9).toString(36)}`;
  }

  // src/storage/archive-repository.ts
  function snapshotIdOf(roomId, date) {
    return `${roomId}:${date}`;
  }
  var ArchiveRepository = class {
    constructor(dbPromise) {
      this.dbPromise = dbPromise;
    }
    db() {
      return this.dbPromise;
    }
    async upsertRoom(room, now) {
      const db = await this.db();
      const tx = db.transaction(STORE_ROOMS, "readwrite");
      const store = tx.objectStore(STORE_ROOMS);
      const existing = await requestToPromise(store.get(room.roomId));
      const record = {
        roomId: room.roomId,
        plotName: room.plotName || existing?.plotName || "",
        url: room.url || existing?.url || "",
        firstSeenAt: existing?.firstSeenAt ?? now,
        lastSeenAt: now
      };
      store.put(record);
      await transactionDone(tx);
      return record;
    }
    /**
     * メッセージ差分を保存する。
     * 順序 (index) と active フラグは content script 側の ConversationStore が
     * 一元管理して確定済みの値を送ってくるため、ここではそれを信頼して
     * そのまま永続化する（capturedAt のみ初回値を保持）。
     */
    async upsertMessages(roomId, records) {
      if (records.length === 0) return;
      const db = await this.db();
      const tx = db.transaction(STORE_MESSAGES, "readwrite");
      const store = tx.objectStore(STORE_MESSAGES);
      for (const incoming of records) {
        if (incoming.roomId !== roomId) continue;
        const existing = await requestToPromise(
          store.get([roomId, incoming.messageKey])
        );
        const merged = existing ? {
          ...existing,
          index: incoming.index,
          role: incoming.role,
          speaker: incoming.speaker,
          parts: incoming.parts,
          contentHash: incoming.contentHash,
          updatedAt: incoming.updatedAt,
          active: incoming.active
        } : incoming;
        store.put(merged);
      }
      await transactionDone(tx);
    }
    async getMessagesForRoom(roomId) {
      const db = await this.db();
      const tx = db.transaction(STORE_MESSAGES, "readonly");
      const index = tx.objectStore(STORE_MESSAGES).index("byRoom");
      const all = await requestToPromise(index.getAll(roomId));
      await transactionDone(tx);
      return all;
    }
    async getActiveMessages(roomId) {
      const all = await this.getMessagesForRoom(roomId);
      return all.filter((m) => m.active).sort((a, b) => a.index - b.index);
    }
    /**
     * 自動保存 (§14)。同一 Room・同一日付では同じ Snapshot を更新する。
     * 全文は複製せず messageKeys から再構成できる形で保持する (§15)。
     */
    async saveSnapshot(room, date, format, now) {
      await this.upsertRoom(room, now);
      const active = await this.getActiveMessages(room.roomId);
      if (active.length === 0) return null;
      const text = formatTranscript(active, format);
      const id = snapshotIdOf(room.roomId, date);
      const db = await this.db();
      const tx = db.transaction(STORE_SNAPSHOTS, "readwrite");
      const store = tx.objectStore(STORE_SNAPSHOTS);
      const existing = await requestToPromise(store.get(id));
      const record = {
        id,
        roomId: room.roomId,
        date,
        displayName: `${room.plotName || "\u7121\u984C"}_${date}`,
        messageKeys: active.map((m) => m.messageKey),
        messageCount: active.length,
        characterCount: countChars(text),
        createdAt: existing?.createdAt ?? now,
        updatedAt: now
      };
      store.put(record);
      await transactionDone(tx);
      return record;
    }
    async listSnapshots() {
      const db = await this.db();
      const tx = db.transaction(STORE_SNAPSHOTS, "readonly");
      const all = await requestToPromise(
        tx.objectStore(STORE_SNAPSHOTS).getAll()
      );
      await transactionDone(tx);
      return all.sort((a, b) => b.updatedAt - a.updatedAt);
    }
    async getSnapshot(id) {
      const db = await this.db();
      const tx = db.transaction(STORE_SNAPSHOTS, "readonly");
      const rec = await requestToPromise(tx.objectStore(STORE_SNAPSHOTS).get(id));
      await transactionDone(tx);
      return rec ?? null;
    }
    /** Snapshot の messageKeys から全文を再構成する (§15)。 */
    async buildSnapshotText(snapshot, format) {
      const db = await this.db();
      const tx = db.transaction(STORE_MESSAGES, "readonly");
      const store = tx.objectStore(STORE_MESSAGES);
      const records = [];
      for (const key of snapshot.messageKeys) {
        const rec = await requestToPromise(store.get([snapshot.roomId, key]));
        if (rec) records.push({ ...rec, active: true, index: records.length + 1 });
      }
      await transactionDone(tx);
      return formatTranscript(records, format);
    }
    async deleteSnapshot(id) {
      const db = await this.db();
      const tx = db.transaction([STORE_SNAPSHOTS, STORE_SUMMARIES], "readwrite");
      tx.objectStore(STORE_SNAPSHOTS).delete(id);
      const bySnapshot = tx.objectStore(STORE_SUMMARIES).index("bySnapshot");
      const summaries = await requestToPromise(bySnapshot.getAll(id));
      for (const s of summaries) {
        tx.objectStore(STORE_SUMMARIES).delete(s.id);
      }
      await transactionDone(tx);
    }
    async saveSummary(summary) {
      const db = await this.db();
      const tx = db.transaction(STORE_SUMMARIES, "readwrite");
      tx.objectStore(STORE_SUMMARIES).put(summary);
      await transactionDone(tx);
    }
    async listSummariesForRoom(roomId) {
      const db = await this.db();
      const tx = db.transaction(STORE_SUMMARIES, "readonly");
      const all = await requestToPromise(
        tx.objectStore(STORE_SUMMARIES).index("byRoom").getAll(roomId)
      );
      await transactionDone(tx);
      return all.sort((a, b) => b.createdAt - a.createdAt);
    }
    async listSummariesForSnapshot(snapshotId) {
      const db = await this.db();
      const tx = db.transaction(STORE_SUMMARIES, "readonly");
      const all = await requestToPromise(
        tx.objectStore(STORE_SUMMARIES).index("bySnapshot").getAll(snapshotId)
      );
      await transactionDone(tx);
      return all.sort((a, b) => b.createdAt - a.createdAt);
    }
  };

  // src/shared/types.ts
  var DEFAULT_SUMMARY_INSTRUCTION = `\u3042\u306A\u305F\u306F\u7269\u8A9E\u306E\u30B3\u30F3\u30C6\u30AD\u30B9\u30C8\u3092\u5727\u7E2E\u3059\u308B\u7DE8\u96C6\u8005\u3067\u3059\u3002

\u4E0E\u3048\u3089\u308C\u305F\u4F1A\u8A71\u30ED\u30B0\u3092\u3001\u6307\u5B9A\u3055\u308C\u305F\u6587\u5B57\u6570\u3092\u76EE\u5B89\u306B\u65E5\u672C\u8A9E\u3067\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002

\u5FC5\u305A\u4FDD\u6301\u3057\u3066\u304F\u3060\u3055\u3044\uFF1A

\u30FB\u767B\u5834\u4EBA\u7269
\u30FB\u4EBA\u7269\u306E\u6027\u683C
\u30FB\u4EBA\u7269\u540C\u58EB\u306E\u95A2\u4FC2
\u30FB\u91CD\u8981\u306A\u51FA\u6765\u4E8B
\u30FB\u611F\u60C5\u3084\u95A2\u4FC2\u6027\u306E\u5909\u5316
\u30FB\u73FE\u5728\u306E\u72B6\u6CC1
\u30FB\u5834\u6240\u3068\u6642\u9593
\u30FB\u672A\u89E3\u6C7A\u306E\u554F\u984C
\u30FB\u4ECA\u5F8C\u306E\u5C55\u958B\u306B\u5FC5\u8981\u306A\u4F0F\u7DDA
\u30FB\u4EBA\u7269\u304C\u660E\u78BA\u306B\u767A\u8A00\u3057\u305F\u91CD\u8981\u306A\u4E8B\u5B9F

\u65B0\u3057\u3044\u8A2D\u5B9A\u3084\u51FA\u6765\u4E8B\u3092\u8FFD\u52A0\u3057\u3066\u306F\u3044\u3051\u307E\u305B\u3093\u3002

\u6587\u7AE0\u3068\u3057\u3066\u81EA\u7136\u306B\u307E\u3068\u3081\u3066\u304F\u3060\u3055\u3044\u3002

\u76EE\u6A19\u6587\u5B57\u6570\uFF1A
{{targetChars}}\u6587\u5B57`;
  function defaultSettings() {
    return {
      autoSaveEnabled: true,
      autoSaveDebounceMs: 2e3,
      defaultTargetChars: 2e3,
      panelWidth: 420,
      layoutMode: "overlay",
      format: {
        speakerLabels: true,
        narrationLabels: true
      },
      provider: "openai-compatible",
      openaiCompatible: {
        endpoint: "http://127.0.0.1:1234/v1/chat/completions",
        model: "",
        temperature: 0.2
      },
      genericJson: {
        url: "",
        method: "POST",
        headers: { "Content-Type": "application/json" },
        requestTemplate: `{
  "model": "{{model}}",
  "prompt": "{{instruction}}\\n\\n{{text}}",
  "target_length": "{{targetChars}}"
}`,
        responsePath: "result.text"
      },
      summaryInstruction: DEFAULT_SUMMARY_INSTRUCTION,
      maxInputCharsPerRequest: 12e3,
      rememberApiKey: false,
      acknowledgedRemoteOrigins: []
    };
  }

  // src/llm/provider.ts
  var LlmError = class extends Error {
    constructor(message, detail) {
      super(message);
      this.detail = detail;
      this.name = "LlmError";
    }
  };
  async function readErrorBody(res) {
    try {
      const text = await res.text();
      return text.slice(0, 500);
    } catch {
      return "";
    }
  }

  // src/llm/openai-compatible.ts
  var OpenAiCompatibleProvider = class {
    constructor(settings, apiKey, fetchFn = fetch) {
      this.settings = settings;
      this.apiKey = apiKey;
      this.fetchFn = fetchFn;
    }
    kind = "openai-compatible";
    get endpoint() {
      return this.settings.endpoint;
    }
    get model() {
      return this.settings.model;
    }
    async summarize(text, options) {
      const body = {
        model: options.model || this.settings.model,
        messages: [
          { role: "system", content: options.instruction },
          { role: "user", content: text }
        ],
        temperature: options.temperature,
        stream: false
      };
      const headers = {
        "Content-Type": "application/json"
      };
      if (this.apiKey) headers["Authorization"] = `Bearer ${this.apiKey}`;
      let res;
      try {
        res = await this.fetchFn(this.settings.endpoint, {
          method: "POST",
          headers,
          body: JSON.stringify(body),
          signal: options.signal
        });
      } catch (e) {
        throw new LlmError(
          `LLM \u3078\u63A5\u7D9A\u3067\u304D\u307E\u305B\u3093: ${e instanceof Error ? e.message : String(e)}`
        );
      }
      if (!res.ok) {
        const detail = await readErrorBody(res);
        throw new LlmError(`LLM \u304C HTTP ${res.status} \u3092\u8FD4\u3057\u307E\u3057\u305F`, truncate(detail, 300));
      }
      let json;
      try {
        json = await res.json();
      } catch {
        throw new LlmError("LLM \u5FDC\u7B54\u304C JSON \u3068\u3057\u3066\u89E3\u6790\u3067\u304D\u307E\u305B\u3093");
      }
      const content = json?.choices?.[0]?.message?.content;
      if (typeof content !== "string" || content.length === 0) {
        throw new LlmError(
          "LLM \u5FDC\u7B54\u306B choices[0].message.content \u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
        );
      }
      return content;
    }
    /** 接続テスト用。/chat/completions → /models へ差し替えられる場合は GET する。 */
    async testConnection() {
      const modelsUrl = deriveModelsUrl(this.settings.endpoint);
      const headers = {};
      if (this.apiKey) headers["Authorization"] = `Bearer ${this.apiKey}`;
      if (modelsUrl) {
        let res;
        try {
          res = await this.fetchFn(modelsUrl, { method: "GET", headers });
        } catch (e) {
          throw new LlmError(
            `\u63A5\u7D9A\u5931\u6557: ${e instanceof Error ? e.message : String(e)}`
          );
        }
        if (!res.ok) {
          throw new LlmError(`HTTP ${res.status}`, await readErrorBody(res));
        }
        try {
          const json = await res.json();
          const ids = (json.data ?? []).map((m) => m.id).filter((id) => typeof id === "string").slice(0, 5);
          return ids.length > 0 ? `\u63A5\u7D9AOK\u3002\u5229\u7528\u53EF\u80FD\u30E2\u30C7\u30EB: ${ids.join(", ")}` : "\u63A5\u7D9AOK\uFF08\u30E2\u30C7\u30EB\u4E00\u89A7\u306F\u7A7A\u3067\u3057\u305F\uFF09";
        } catch {
          return "\u63A5\u7D9AOK";
        }
      }
      await this.summarize("\u63A5\u7D9A\u30C6\u30B9\u30C8\u3067\u3059\u3002\u300COK\u300D\u3068\u3060\u3051\u8FD4\u3057\u3066\u304F\u3060\u3055\u3044\u3002", {
        targetChars: 10,
        instruction: "\u300COK\u300D\u3068\u3060\u3051\u8FD4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        model: this.settings.model,
        temperature: 0
      });
      return "\u63A5\u7D9AOK";
    }
  };
  function deriveModelsUrl(endpoint) {
    try {
      const u = new URL(endpoint);
      if (u.pathname.endsWith("/chat/completions")) {
        u.pathname = u.pathname.replace(/\/chat\/completions$/, "/models");
        u.search = "";
        return u.toString();
      }
      return null;
    } catch {
      return null;
    }
  }

  // src/llm/generic-json.ts
  var GenericJsonProvider = class {
    constructor(settings, apiKey, fetchFn = fetch) {
      this.settings = settings;
      this.apiKey = apiKey;
      this.fetchFn = fetchFn;
    }
    kind = "generic-json";
    get endpoint() {
      return this.settings.url;
    }
    get model() {
      return "";
    }
    async summarize(text, options) {
      const values = {
        text,
        targetChars: String(options.targetChars),
        instruction: options.instruction,
        model: options.model,
        apiKey: this.apiKey ?? ""
      };
      const headers = {};
      for (const [name, value2] of Object.entries(this.settings.headers ?? {})) {
        headers[name] = substitutePlaceholders(value2, values);
      }
      const init = {
        method: this.settings.method,
        headers,
        signal: options.signal
      };
      if (this.settings.method !== "GET") {
        const body = buildRequestBody(this.settings.requestTemplate, values);
        init.body = JSON.stringify(body);
        if (!hasHeader(headers, "content-type")) {
          headers["Content-Type"] = "application/json";
        }
      }
      let res;
      try {
        res = await this.fetchFn(this.settings.url, init);
      } catch (e) {
        throw new LlmError(
          `LLM \u3078\u63A5\u7D9A\u3067\u304D\u307E\u305B\u3093: ${e instanceof Error ? e.message : String(e)}`
        );
      }
      if (!res.ok) {
        const detail = await readErrorBody(res);
        throw new LlmError(`LLM \u304C HTTP ${res.status} \u3092\u8FD4\u3057\u307E\u3057\u305F`, truncate(detail, 300));
      }
      let json;
      try {
        json = await res.json();
      } catch {
        throw new LlmError("LLM \u5FDC\u7B54\u304C JSON \u3068\u3057\u3066\u89E3\u6790\u3067\u304D\u307E\u305B\u3093");
      }
      const value = getByPath(json, this.settings.responsePath);
      if (typeof value !== "string" || value.length === 0) {
        throw new LlmError(
          `Response JSON Path "${this.settings.responsePath}" \u304B\u3089\u6587\u5B57\u5217\u3092\u53D6\u5F97\u3067\u304D\u307E\u305B\u3093`
        );
      }
      return value;
    }
  };
  function buildRequestBody(template, values) {
    let parsed;
    try {
      parsed = JSON.parse(template);
    } catch (e) {
      throw new LlmError(
        `JSON Request Template \u3092\u89E3\u6790\u3067\u304D\u307E\u305B\u3093: ${e instanceof Error ? e.message : String(e)}`
      );
    }
    return substituteDeep(parsed, values);
  }
  function substituteDeep(node, values) {
    if (typeof node === "string") {
      return substitutePlaceholders(node, values);
    }
    if (Array.isArray(node)) {
      return node.map((item) => substituteDeep(item, values));
    }
    if (node !== null && typeof node === "object") {
      const out = {};
      for (const [k, v] of Object.entries(node)) {
        out[k] = substituteDeep(v, values);
      }
      return out;
    }
    return node;
  }
  function hasHeader(headers, lowerName) {
    return Object.keys(headers).some((k) => k.toLowerCase() === lowerName);
  }

  // src/llm/summarizer.ts
  var TARGET_MAX_RATIO = 1.1;
  var MAX_RECOMPRESS = 2;
  var MAX_REDUCE_DEPTH = 3;
  async function runSummarization(provider, fullText, options) {
    const maxInput = Math.max(1e3, options.maxInputCharsPerRequest);
    const segments = fullText.split(MESSAGE_SEPARATOR);
    const chunks = chunkSegments(segments, maxInput);
    const finalInstruction = substitutePlaceholders(options.instructionTemplate, {
      targetChars: String(options.targetChars)
    });
    const callProvider = (text, instruction, targetChars) => provider.summarize(text, {
      targetChars,
      instruction,
      model: options.model,
      temperature: options.temperature,
      signal: options.signal
    });
    let finalText;
    if (chunks.length === 1) {
      options.onProgress?.("\u8981\u7D04\u4E2D\u2026");
      finalText = (await callProvider(chunks[0], finalInstruction, options.targetChars)).trim();
    } else {
      let intermediates = [];
      for (let i = 0; i < chunks.length; i++) {
        options.onProgress?.(`\u5206\u5272\u8981\u7D04\u4E2D\u2026 (${i + 1}/${chunks.length})`);
        const target = intermediateTargetChars(options.targetChars, chunks.length);
        const instruction = intermediateInstruction(i + 1, chunks.length, target);
        const summary = await callProvider(chunks[i], instruction, target);
        intermediates.push(summary.trim());
      }
      let depth = 0;
      while (countChars(intermediates.join("\n\n")) > maxInput && intermediates.length > 1 && depth < MAX_REDUCE_DEPTH) {
        depth++;
        const rechunks = chunkSegments(intermediates, maxInput);
        const next = [];
        for (let i = 0; i < rechunks.length; i++) {
          options.onProgress?.(`\u4E2D\u9593\u8981\u7D04\u3092\u518D\u5727\u7E2E\u4E2D\u2026 (${i + 1}/${rechunks.length})`);
          const target = intermediateTargetChars(options.targetChars, rechunks.length);
          const instruction = intermediateInstruction(i + 1, rechunks.length, target);
          next.push((await callProvider(rechunks[i], instruction, target)).trim());
        }
        intermediates = next;
      }
      options.onProgress?.("\u6700\u7D42\u8981\u7D04\u3092\u751F\u6210\u4E2D\u2026");
      const combined = "\u4EE5\u4E0B\u306F\u9577\u3044\u4F1A\u8A71\u30ED\u30B0\u3092\u6642\u7CFB\u5217\u9806\u306B\u5206\u5272\u3057\u3066\u4F5C\u6210\u3057\u305F\u4E2D\u9593\u8981\u7D04\u3067\u3059\u3002\u3053\u308C\u3089\u3092 1 \u3064\u306E\u8981\u7D04\u306B\u7D71\u5408\u3057\u3066\u304F\u3060\u3055\u3044\u3002\n\n" + intermediates.join("\n\n");
      finalText = (await callProvider(combined, finalInstruction, options.targetChars)).trim();
    }
    let recompressCount = 0;
    while (countChars(finalText) > options.targetChars * TARGET_MAX_RATIO && recompressCount < MAX_RECOMPRESS) {
      recompressCount++;
      options.onProgress?.(
        `\u76EE\u6A19\u6587\u5B57\u6570\u3078\u518D\u5727\u7E2E\u4E2D\u2026 (${recompressCount}/${MAX_RECOMPRESS})`
      );
      const instruction = `\u3053\u306E\u5185\u5BB9\u3092\u7DAD\u6301\u3057\u305F\u307E\u307E${options.targetChars}\u6587\u5B57\u7A0B\u5EA6\u307E\u3067\u518D\u5727\u7E2E\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u65B0\u3057\u3044\u8A2D\u5B9A\u3084\u51FA\u6765\u4E8B\u3092\u8FFD\u52A0\u305B\u305A\u3001\u6587\u7AE0\u3068\u3057\u3066\u81EA\u7136\u306B\u307E\u3068\u3081\u3066\u304F\u3060\u3055\u3044\u3002`;
      finalText = (await callProvider(finalText, instruction, options.targetChars)).trim();
    }
    return {
      text: finalText,
      chars: countChars(finalText),
      chunkCount: chunks.length,
      recompressCount
    };
  }
  function chunkSegments(segments, maxChars) {
    const sepLen = MESSAGE_SEPARATOR.length;
    const chunks = [];
    let current = [];
    let currentLen = 0;
    const flush = () => {
      if (current.length > 0) {
        chunks.push(current.join(MESSAGE_SEPARATOR));
        current = [];
        currentLen = 0;
      }
    };
    for (const segment of segments) {
      if (segment.length === 0) continue;
      if (segment.length > maxChars) {
        flush();
        for (const piece of splitOversized(segment, maxChars)) {
          chunks.push(piece);
        }
        continue;
      }
      const addedLen = current.length === 0 ? segment.length : segment.length + sepLen;
      if (currentLen + addedLen > maxChars) flush();
      current.push(segment);
      currentLen += current.length === 1 ? segment.length : segment.length + sepLen;
    }
    flush();
    return chunks.length > 0 ? chunks : [""];
  }
  function splitOversized(text, maxChars) {
    const paragraphs = text.split("\n\n");
    const out = [];
    let buf = "";
    for (const p of paragraphs) {
      const candidate = buf.length === 0 ? p : `${buf}

${p}`;
      if (candidate.length > maxChars && buf.length > 0) {
        out.push(buf);
        buf = p;
      } else {
        buf = candidate;
      }
      while (buf.length > maxChars) {
        out.push(buf.slice(0, maxChars));
        buf = buf.slice(maxChars);
      }
    }
    if (buf.length > 0) out.push(buf);
    return out;
  }
  function intermediateTargetChars(targetChars, chunkCount) {
    const raw = Math.ceil(targetChars * 1.5 / Math.max(1, chunkCount));
    return Math.min(3e3, Math.max(300, raw));
  }
  function intermediateInstruction(part, total, targetChars) {
    return `\u3042\u306A\u305F\u306F\u7269\u8A9E\u306E\u30B3\u30F3\u30C6\u30AD\u30B9\u30C8\u3092\u5727\u7E2E\u3059\u308B\u7DE8\u96C6\u8005\u3067\u3059\u3002
\u3053\u308C\u306F\u9577\u3044\u4F1A\u8A71\u30ED\u30B0\u3092\u6642\u7CFB\u5217\u9806\u306B\u5206\u5272\u3057\u305F\u3082\u306E\u306E\u4E00\u90E8\uFF08${part}/${total}\uFF09\u3067\u3059\u3002

\u767B\u5834\u4EBA\u7269\u30FB\u6027\u683C\u30FB\u95A2\u4FC2\u30FB\u91CD\u8981\u306A\u51FA\u6765\u4E8B\u30FB\u611F\u60C5\u3084\u95A2\u4FC2\u6027\u306E\u5909\u5316\u30FB\u5834\u6240\u3068\u6642\u9593\u30FB\u672A\u89E3\u6C7A\u306E\u554F\u984C\u30FB\u4F0F\u7DDA\u30FB\u660E\u78BA\u306B\u767A\u8A00\u3055\u308C\u305F\u91CD\u8981\u306A\u4E8B\u5B9F\u3092\u6B20\u843D\u3055\u305B\u305A\u3001\u6642\u7CFB\u5217\u9806\u3092\u4FDD\u3063\u305F\u307E\u307E\u65E5\u672C\u8A9E\u3067\u8981\u7D04\u3057\u3066\u304F\u3060\u3055\u3044\u3002

\u65B0\u3057\u3044\u8A2D\u5B9A\u3084\u51FA\u6765\u4E8B\u3092\u8FFD\u52A0\u3057\u3066\u306F\u3044\u3051\u307E\u305B\u3093\u3002

\u76EE\u6A19\u6587\u5B57\u6570\uFF1A
${targetChars}\u6587\u5B57`;
  }

  // src/background/service-worker.ts
  var repo = new ArchiveRepository(openDatabase());
  var SETTINGS_KEY = "settings";
  var API_KEY_KEY = "apiKey";
  async function restrictSessionStorage() {
    try {
      await chrome.storage.session.setAccessLevel({
        accessLevel: "TRUSTED_CONTEXTS"
      });
    } catch {
    }
  }
  void restrictSessionStorage();
  chrome.runtime.onInstalled.addListener(() => {
    void restrictSessionStorage();
  });
  chrome.action?.onClicked.addListener(() => {
    void chrome.runtime.openOptionsPage();
  });
  function mergeSettings(stored) {
    const d = defaultSettings();
    if (!stored) return d;
    return {
      ...d,
      ...stored,
      format: { ...d.format, ...stored.format ?? {} },
      openaiCompatible: { ...d.openaiCompatible, ...stored.openaiCompatible ?? {} },
      genericJson: { ...d.genericJson, ...stored.genericJson ?? {} },
      acknowledgedRemoteOrigins: Array.isArray(stored.acknowledgedRemoteOrigins) ? stored.acknowledgedRemoteOrigins : d.acknowledgedRemoteOrigins
    };
  }
  async function loadSettings() {
    const stored = await chrome.storage.local.get(SETTINGS_KEY);
    return mergeSettings(stored[SETTINGS_KEY]);
  }
  async function persistSettings(settings) {
    await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  }
  async function getApiKey() {
    const session = await chrome.storage.session.get(API_KEY_KEY);
    if (typeof session[API_KEY_KEY] === "string" && session[API_KEY_KEY]) {
      return session[API_KEY_KEY];
    }
    const local = await chrome.storage.local.get(API_KEY_KEY);
    if (typeof local[API_KEY_KEY] === "string" && local[API_KEY_KEY]) {
      return local[API_KEY_KEY];
    }
    return null;
  }
  async function setApiKey(value, remember) {
    if (value === "") {
      await chrome.storage.session.remove(API_KEY_KEY);
      await chrome.storage.local.remove(API_KEY_KEY);
      return;
    }
    if (remember) {
      await chrome.storage.local.set({ [API_KEY_KEY]: value });
      await chrome.storage.session.remove(API_KEY_KEY);
    } else {
      await chrome.storage.session.set({ [API_KEY_KEY]: value });
      await chrome.storage.local.remove(API_KEY_KEY);
    }
  }
  function resolveEndpoint(settings) {
    return settings.provider === "openai-compatible" ? settings.openaiCompatible.endpoint : settings.genericJson.url;
  }
  function buildProvider(settings, apiKey) {
    if (settings.provider === "openai-compatible") {
      return new OpenAiCompatibleProvider(settings.openaiCompatible, apiKey);
    }
    return new GenericJsonProvider(settings.genericJson, apiKey);
  }
  var HandlerError = class extends Error {
    constructor(code, message, origin) {
      super(message);
      this.code = code;
      this.origin = origin;
    }
  };
  async function ensureEndpointAllowed(settings, options) {
    const endpoint = resolveEndpoint(settings);
    if (!endpoint) {
      throw new HandlerError(
        "PROVIDER_NOT_CONFIGURED",
        "LLM Provider \u306E Endpoint \u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002SETTINGS \u30BF\u30D6\u3067\u8A2D\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044\u3002"
      );
    }
    const origin = originOf(endpoint);
    const pattern = originPatternOf(endpoint);
    if (!origin || !pattern) {
      throw new HandlerError(
        "PROVIDER_NOT_CONFIGURED",
        `Endpoint URL \u304C\u4E0D\u6B63\u3067\u3059: ${endpoint}`
      );
    }
    if (isLocalEndpoint(endpoint)) {
      return "LOCAL";
    }
    if (options.requireAcknowledge) {
      const acknowledged = settings.acknowledgedRemoteOrigins.includes(origin);
      if (!acknowledged && !options.confirmRemote) {
        throw new HandlerError(
          "NEEDS_REMOTE_CONFIRM",
          `\u3053\u306E\u4F1A\u8A71\u30ED\u30B0\u306F\u8A2D\u5B9A\u3055\u308C\u305F\u5916\u90E8LLM\u30B5\u30FC\u30D3\u30B9\u3078\u9001\u4FE1\u3055\u308C\u307E\u3059\u3002\u9001\u4FE1\u5148: ${origin}`,
          origin
        );
      }
      if (!acknowledged && options.confirmRemote) {
        settings.acknowledgedRemoteOrigins = [
          ...settings.acknowledgedRemoteOrigins,
          origin
        ];
        await persistSettings(settings);
      }
    }
    const granted = await chrome.permissions.contains({ origins: [pattern] });
    if (!granted) {
      throw new HandlerError(
        "NEEDS_HOST_PERMISSION",
        `${origin} \u3078\u306E\u30A2\u30AF\u30BB\u30B9\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093\u3002\u62E1\u5F35\u6A5F\u80FD\u306E\u30AA\u30D7\u30B7\u30E7\u30F3\u30DA\u30FC\u30B8\u304B\u3089\u8A31\u53EF\u3057\u3066\u304F\u3060\u3055\u3044\u3002`,
        origin
      );
    }
    return "REMOTE";
  }
  function startKeepAlive() {
    const timer = setInterval(() => {
      void chrome.runtime.getPlatformInfo();
    }, 2e4);
    return () => clearInterval(timer);
  }
  function pushProgress(tabId, message) {
    if (tabId === void 0) return;
    chrome.tabs.sendMessage(tabId, { type: "SUMMARY_PROGRESS", message }).catch(() => {
    });
  }
  async function handleRequest(request, sender) {
    switch (request.type) {
      case "UPSERT_MESSAGES": {
        const now = Date.now();
        await repo.upsertRoom(request.room, now);
        await repo.upsertMessages(request.room.roomId, request.records);
        return { stored: request.records.length };
      }
      case "SAVE_SNAPSHOT": {
        const now = Date.now();
        const settings = await loadSettings();
        const snapshot = await repo.saveSnapshot(
          request.room,
          formatDateLocal(now),
          settings.format,
          now
        );
        if (!snapshot) {
          throw new HandlerError("NOT_FOUND", "\u4FDD\u5B58\u5BFE\u8C61\u306E\u30E1\u30C3\u30BB\u30FC\u30B8\u304C\u3042\u308A\u307E\u305B\u3093");
        }
        const result = { snapshot, savedAt: now };
        return result;
      }
      case "GET_ROOM_MESSAGES": {
        return await repo.getActiveMessages(request.roomId);
      }
      case "GET_ARCHIVES": {
        return await repo.listSnapshots();
      }
      case "GET_ARCHIVE": {
        const snapshot = await repo.getSnapshot(request.snapshotId);
        if (!snapshot) {
          throw new HandlerError("NOT_FOUND", "\u30A2\u30FC\u30AB\u30A4\u30D6\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
        }
        const settings = await loadSettings();
        const text = await repo.buildSnapshotText(snapshot, settings.format);
        const summaries = await repo.listSummariesForSnapshot(snapshot.id);
        const detail = { snapshot, text, summaries };
        return detail;
      }
      case "DELETE_ARCHIVE": {
        await repo.deleteSnapshot(request.snapshotId);
        return { deleted: true };
      }
      case "SUMMARIZE": {
        const settings = await loadSettings();
        const endpointKind = await ensureEndpointAllowed(settings, {
          confirmRemote: request.confirmRemote === true,
          requireAcknowledge: true
        });
        const apiKey = await getApiKey();
        const provider = buildProvider(settings, apiKey);
        const tabId = sender.tab?.id;
        const stopKeepAlive = startKeepAlive();
        try {
          const job = await runSummarization(provider, request.text, {
            targetChars: request.targetChars,
            instructionTemplate: settings.summaryInstruction,
            model: provider.model,
            temperature: settings.provider === "openai-compatible" ? settings.openaiCompatible.temperature : 0.2,
            maxInputCharsPerRequest: settings.maxInputCharsPerRequest,
            onProgress: (message) => pushProgress(tabId, message)
          });
          const result = {
            text: job.text,
            chars: job.chars,
            chunkCount: job.chunkCount,
            recompressCount: job.recompressCount,
            endpointKind,
            provider: settings.provider,
            model: provider.model
          };
          return result;
        } catch (e) {
          if (e instanceof LlmError) {
            const detail = e.detail ? ` (${e.detail})` : "";
            throw new HandlerError("LLM_ERROR", `${e.message}${detail}`);
          }
          throw e;
        } finally {
          stopKeepAlive();
        }
      }
      case "SAVE_SUMMARY": {
        const record = {
          id: randomId(),
          roomId: request.summary.roomId ?? "",
          snapshotId: request.summary.snapshotId,
          sourceLabel: request.summary.sourceLabel,
          provider: request.summary.provider,
          model: request.summary.model,
          targetChars: request.summary.targetChars,
          actualChars: request.summary.actualChars,
          text: request.summary.text,
          createdAt: Date.now()
        };
        await repo.saveSummary(record);
        return record;
      }
      case "GET_SUMMARIES": {
        return await repo.listSummariesForRoom(request.roomId);
      }
      case "GET_SETTINGS": {
        const settings = await loadSettings();
        const hasApiKey = await getApiKey() !== null;
        const result = { settings, hasApiKey };
        return result;
      }
      case "SAVE_SETTINGS": {
        const merged = mergeSettings(request.settings);
        await persistSettings(merged);
        if (request.apiKey !== void 0) {
          await setApiKey(request.apiKey, merged.rememberApiKey);
        } else {
          const existing = await getApiKey();
          if (existing !== null) await setApiKey(existing, merged.rememberApiKey);
        }
        const hasApiKey = await getApiKey() !== null;
        const result = { settings: merged, hasApiKey };
        return result;
      }
      case "TEST_LLM_CONNECTION": {
        const settings = await loadSettings();
        const endpointKind = await ensureEndpointAllowed(settings, {
          confirmRemote: false,
          requireAcknowledge: false
        });
        const apiKey = await getApiKey();
        try {
          let detail;
          if (settings.provider === "openai-compatible") {
            const provider = new OpenAiCompatibleProvider(
              settings.openaiCompatible,
              apiKey
            );
            detail = await provider.testConnection();
          } else {
            const provider = new GenericJsonProvider(settings.genericJson, apiKey);
            const out = await provider.summarize(
              "\u63A5\u7D9A\u30C6\u30B9\u30C8\u3067\u3059\u3002\u300COK\u300D\u3068\u3060\u3051\u8FD4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
              {
                targetChars: 10,
                instruction: "\u300COK\u300D\u3068\u3060\u3051\u8FD4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
                model: "",
                temperature: 0
              }
            );
            detail = `\u63A5\u7D9AOK\u3002\u5FDC\u7B54: ${out.slice(0, 50)}`;
          }
          const result = { ok: true, endpointKind, detail };
          return result;
        } catch (e) {
          const message = e instanceof LlmError ? `${e.message}${e.detail ? ` (${e.detail})` : ""}` : e instanceof Error ? e.message : String(e);
          const result = {
            ok: false,
            endpointKind,
            detail: message
          };
          return result;
        }
      }
      case "OPEN_OPTIONS": {
        await chrome.runtime.openOptionsPage();
        return { opened: true };
      }
      default: {
        const exhaustive = request;
        throw new HandlerError("INTERNAL", `\u672A\u77E5\u306E\u30E1\u30C3\u30BB\u30FC\u30B8: ${JSON.stringify(exhaustive)}`);
      }
    }
  }
  chrome.runtime.onMessage.addListener(
    (request, sender, sendResponse) => {
      if (!request || typeof request !== "object" || !("type" in request)) {
        return false;
      }
      handleRequest(request, sender).then((data) => sendResponse({ ok: true, data })).catch((e) => {
        if (e instanceof HandlerError) {
          sendResponse({
            ok: false,
            error: e.message,
            code: e.code,
            origin: e.origin
          });
        } else {
          sendResponse({
            ok: false,
            error: e instanceof Error ? e.message : String(e),
            code: "INTERNAL"
          });
        }
      });
      return true;
    }
  );
})();
